#include <stdio.h>

/*---------------------------------------------*/
unsigned int compactaHora(unsigned int hora, unsigned int minuto, unsigned int segundo){
    unsigned int res = 0;
    
    res = hora;
    res <<= 8;
    res |= minuto;
    res <<= 8;
    res |= segundo;
    return res;
}

/*---------------------------------------------*/
void descompactaHora(unsigned int horaCompactada, unsigned int *hora, unsigned int *minuto, unsigned int *segundo){

    *segundo = horaCompactada & 0x000000ff;
    *minuto = (horaCompactada & 0x0000ff00) >> 8;
    *hora =   (horaCompactada & 0x00ff0000) >> 16;
}

/*---------------------------------------------*/
int main(){
    unsigned int hora, minuto, segundo;
    unsigned int h, m, s;

    printf("Digite a hora, minuto e segundo:\n");
    scanf("%u %u %u", &hora, &minuto, &segundo);

    unsigned int compac = compactaHora(hora, minuto, segundo);
    printf("Compactada: %x %u\n", compac, compac);

    descompactaHora(compac, &h, &m, &s);
    printf("Descompactada: %u %u %u\n", h, m, s);
        
}
/*---------------------------------------------*/


