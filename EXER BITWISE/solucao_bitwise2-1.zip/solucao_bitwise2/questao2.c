#include <stdio.h>

/*---------------------------------------------*/

unsigned int compactaHora(unsigned int hora, unsigned int minuto, unsigned int segundo){
    unsigned int res = 0;
    
    res = hora;
    res <<= 8;
    res |= minuto;
    res <<= 8;
    res |= segundo;
    return res;
}

/*---------------------------------------------*/
int main(){
    unsigned int hora, minuto, segundo;

    printf("Digite a hora, minuto e segundo:\n");
    scanf("%u %u %u", &hora, &minuto, &segundo);

    unsigned int compac = compactaHora(hora, minuto, segundo);
    printf("%x %u\n", compac, compac);
     
}
/*---------------------------------------------*/


