#include <stdio.h>

/*-----------------------------------------------------------------*/
unsigned int crossover(unsigned int n1, unsigned int n2){

    unsigned int res = 0;

    res = n1 & 0xffff0000;
    res |= n2 & 0x0000ffff;
    return res;    
}


/*-----------------------------------------------------------------*/
int  main() {
   unsigned int x = crossover(305419896,1737075661);
   printf("%u %x\n", x, x);
}

/*-----------------------------------------------------------------*/
