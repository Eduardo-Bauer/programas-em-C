#include <stdio.h>

/*---------------------------------------------*/
void troca(int *a, int *b){
	*a = *a ^ *b;
	*b = *a ^ *b;
	*a = *a ^ *b;
}

/*---------------------------------------------*/
int main(){
	int a, b;
	
	printf("Digite os valores:\n");
	scanf("%d %d", &a, &b);
	
	troca(&a, &b);
	
	printf("a= %d b= %d\n", a, b);

}
/*---------------------------------------------*/
