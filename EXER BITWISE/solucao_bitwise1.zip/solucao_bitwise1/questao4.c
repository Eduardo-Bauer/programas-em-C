#include <stdio.h>

/*---------------------------------------------*/
char minuscula(char c){
	if ( c>='A' &&  c <='Z'){
		c = c | 32;
	}
	return c;
}

/*---------------------------------------------*/
int main(){
	char c;
	
	printf("Digite o caracter:\n");
	scanf("%c", &c);
	
	printf("Maiuscula: %c\n", minuscula(c));
	
}
/*---------------------------------------------*/
