#include <stdio.h>

/*---------------------------------------------*/
unsigned short int compactaCaracteres(char a, char b){
    unsigned short int res = 0;
    res = a;
    res <<= 8;
    res |= b;      
    return res;
}

/*---------------------------------------------*/
void descompactaCaracteres(unsigned short int c, char *a, char *b){
    
    *b = c & 0xff;
    c >>= 8;
    *a = c & 0xff;
   
}
/*---------------------------------------------*/
int main(){
	char a, b;
    char r1, r2;
	
	printf("Digite os dois caracteres:\n");
    scanf("%c %c", &a, &b);

    short int aux =  compactaCaracteres(a,b);
	printf("Compactado: %x\n", aux);

    descompactaCaracteres(aux, &r1, &r2);
    printf("Descompactado: %c %c\n", r1, r2);

}
/*---------------------------------------------*/
