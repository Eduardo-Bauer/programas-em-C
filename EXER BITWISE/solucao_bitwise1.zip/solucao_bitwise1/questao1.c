#include <stdio.h>

/*---------------------------------------------*/
int impar(int n){
	return (n&1);
}

/*---------------------------------------------*/
int main(){
	int n;
	
	printf("Digite o valor:\n");
	scanf("%d", &n);

	if ( impar(n) ){
		printf("%d e impar\n", n);
	}
	else{
		printf("%d nao e impar\n", n);
	}
}
/*---------------------------------------------*/
