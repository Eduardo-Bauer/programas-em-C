#include <stdio.h>

/*---------------------------------------------*/
char maiuscula(char c){
	if ( c>='a' &&  c <='z'){
		c = c & 0xdf;
	}
	return c;
}

/*---------------------------------------------*/
int main(){
	char c;
	
	printf("Digite o caracter:\n");
	scanf("%c", &c);
	
	printf("Maiuscula: %c\n", maiuscula(c));
	
}
/*---------------------------------------------*/
