#include <stdio.h>

/*---------------------------------------------*/
void escreve_bits(int n){
    int i;

    for(i=0; i<32; i++){
        printf("%d", (n>>31) & 1);
        n <<= 1;    
    }	

}

/*---------------------------------------------*/
int main(){
	int n;
	
	printf("Digite o valor:\n");
	scanf("%d", &n);

	escreve_bits(n);
}
/*---------------------------------------------*/
