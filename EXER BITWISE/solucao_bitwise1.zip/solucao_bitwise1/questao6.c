#include <stdio.h>

/*---------------------------------------------*/
unsigned short int compactaCaracteres(char a, char b){
    unsigned short int res = 0;
    res = a;
    res <<= 8;
    res |= b;      
    return res;
}
/*---------------------------------------------*/
int main(){
	char a, b;
	
	printf("Digite os dois caracteres:\n");
    scanf("%c %c", &a, &b);

    printf("%x\n", compactaCaracteres(a,b));
	
}
/*---------------------------------------------*/
