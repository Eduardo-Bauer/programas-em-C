#include <stdio.h>

#define N 5

void main(){
  int mat[5][5];
  int i, j, soma;
  
  for(i=0; i<5; i++){
      for(j=0; j<5; j++){
          printf("Digite o valor:\n");
          scanf("%d", &mat[i][j]);
      }
  }

  soma = 0;
  for(i=0; i<5; i++){
      soma += mat[i][i];
  }
    
  printf("Soma: %d\n", soma);
}

