#include <stdio.h>

#define N 5

void main(){
  int mat[N][N];
  int i, j, identidade;
  
  
  for(i=0; i<N; i++){
      for(j=0; j<N; j++){
          printf("Digite o valor:\n");
          scanf("%d", &mat[i][j]);
      }
  }

  identidade = 1;
  for(i=0; i<N; i++){
      for(j=0; j<N; j++){
                     if ((i==j && mat[i][j]!=1) || (i!=j && mat[i][j]!=0)){
                              identidade = 0; 
                     }
      }
  }

  printf("Identidade: %d\n", identidade); 
  
}

