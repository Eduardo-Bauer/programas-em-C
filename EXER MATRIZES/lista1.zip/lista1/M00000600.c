#include <stdio.h>

#define N 5

void main(){
  int mat[N][N];
  int i, j, aux;
  
  
  for(i=0; i<N; i++){
      for(j=0; j<N; j++){
          printf("Digite o valor:\n");
          scanf("%d", &mat[i][j]);
      }
  }

  for(j=0; j<N; j++){
  	aux = mat[1][j];
  	mat[1][j] = mat[3][j];
  	mat[3][j] = aux;
  }
    
  for(i=0; i<N; i++){
      for(j=0; j<N; j++){
          printf("%d ", mat[i][j]);
      }
      printf("\n");
  }
  
}

