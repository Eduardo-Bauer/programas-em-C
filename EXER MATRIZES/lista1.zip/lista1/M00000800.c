#include <stdio.h>

#define N 5

void main(){
  int mat[N][N];
  int i, j, soma, maior, l;
  
  
  for(i=0; i<N; i++){
      for(j=0; j<N; j++){
          printf("Digite o valor:\n");
          scanf("%d", &mat[i][j]);
      }
  }

  maior = 0;
  l = 0;
  for(i=0; i<N; i++){
  	 soma = 0;
      for(j=0; j<N; j++){
          soma += mat[i][j];      
      }
      if (soma > maior){
      	maior = soma;
      	l = i;
      }
  }

  printf("Maior soma: %d\n", maior);
  printf("Linha: %d\n", l + 1);
}

