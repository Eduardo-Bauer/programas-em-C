#include <stdio.h>

#define N 5

void main(){
  int mat[N][N];
  int i, j, maior, l, c;
  
  
  for(i=0; i<N; i++){
      for(j=0; j<N; j++){
          printf("Digite o valor:\n");
          scanf("%d", &mat[i][j]);
      }
  }

  l = 0;
  c = 0;
  maior = mat[0][0];
  for(i=0; i<N; i++){
      for(j=0; j<N; j++){
      	if ( mat[i][j] > maior){
      		maior = mat[i][j];
      		l = i;
      		c = j;
      	}
      }
  }
    
  printf("Maior: %d Linha: %d Coluna: %d\n", maior, l+1, c+1);
  
}

