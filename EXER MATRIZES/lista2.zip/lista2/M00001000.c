#include <stdio.h>
// Autor : Andre  Martinotto
// Data : 13/08/2018

#define N 5
void main(){
  int mat[5][5];
  int somalin[5], somacol[5];
  int i, j;
  
  for(i=0; i<5; i++){
      for(j=0; j<5; j++){
          printf("Digite o valor:\n");
          scanf("%d", &mat[i][j]);
      }
  }
    
  for(i=0; i<5; i++){
      somalin[i] = 0;
      somacol[i] = 0;
      for(j=0; j<5; j++){
          somalin[i] += mat[i][j];
          somacol[i] += mat[j][i];
      }
  }
    
  for(i=0; i<5; i++){
      printf("somalin: %d\n", somalin[i]);
  }
    
  for(i=0; i<5; i++){
      printf("somacol: %d\n", somacol[i]);
  }
    
}

