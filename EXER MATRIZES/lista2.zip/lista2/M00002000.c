#include <stdio.h>
// Autor : Andre  Martinotto
// Data : 13/08/2018

#define N 5

void main(){
  int mat[5][5];
  int i, j;
  int acima, abaixo, diagonal, saida;
  
  for(i=0; i<5; i++){
      for(j=0; j<5; j++){
          printf("Digite o valor:\n");
          scanf("%d", &mat[i][j]);
      }
  }
    
  acima = abaixo = diagonal = 0;
  
  for(i=0; i<5; i++){
      for(j=0; j<5; j++){
          if ( i==j && mat[i][j] != 0){
              diagonal++;
          }
          else if ( i < j && mat[i][j] != 0){
               acima++;
          }
          else if (mat[i][j] != 0){
               abaixo++;
          }
      }
  }
    
  if ( diagonal && !acima && !abaixo){
      saida = 0;
  }
  else if ( !abaixo && acima){
      saida = 1;
  }
  else if ( !acima && abaixo){
      saida = 2;
  }
  else{
      saida = 3;
  }
        
  printf("Matriz: %d\n", saida);
  
}

