#include <stdio.h>
#include <math.h>
// Autor : Andre  Martinotto
// Data : 13/08/2018
void main(){
  int mat[5][6];
  int i, j, menor;
  
  for(i=0; i<5; i++){
      for(j=0; j<6; j++){
          printf("Digite o valor:\n");
          scanf("%d", &mat[i][j]);
      }
  }
    
    
  for(i=0; i<5; i++){
      menor = mat[i][0];
      for(j=1; j<6; j++){
          if ( fabs(mat[i][j]) < fabs(menor)){
              menor = mat[i][j];
          }
      }
        
      for(j=0;j<6; j++){
          mat[i][j] /= menor;
      }
  }
    
  for(i=0; i<5; i++){
      for(j=0; j<6; j++){
          printf("%d ",mat[i][j]);
      }
      printf("\n");
  }
     
}

