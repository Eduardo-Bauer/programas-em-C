#include <stdio.h>
#include <math.h>
// Autor : Andre  Martinotto
// Data : 13/08/2018
void main(){
  int mat[5][5];
  int i, j, k, lin, col;
  int n, existe;
  
  for(i=0; i<5; i++){
      for(j=0; j<5; j++){
          printf("Digite o valor:\n");
          scanf("%d", &mat[i][j]);
      }
  }
    
  for(k=0; k<5; k++){
      printf("Digite o valor:\n");
      scanf("%d", &n);
      
      existe = 0;
      for(i=0; i<5; i++){
          for(j=0; j<5; j++){
              if(n == mat[i][j] && existe == 0){
                  existe = 1;
                  lin = i;
                  col = j;
              }
          }
      }
        
      if ( !existe ){
          printf("Não tem\n");
      }
      else{
          printf("Posicao: %d e %d\n", lin+1, col+1);
      }
  }
    
}

