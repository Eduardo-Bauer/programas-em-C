#include <stdio.h>
// Autor : Andre  Martinotto
// Data : 13/08/2018

void main(){
  int mat[5][5];
  int soma[6];
  int s, i, j, vai;
  
  for(i=0; i<5; i++){
      for(j=0; j<5; j++){
          printf("Digite o valor:\n");
          scanf("%d", &mat[i][j]);
      }
  }
    
  vai = 0;
  for(j=4; j>=0; j--){
      s = vai;
      for(i=0; i<5; i++){
          s += mat[i][j];
      }
      soma[j+1] = s % 10;
      vai = s /10;
  }
  soma[0] = vai;
  
  for(i=0; i<6; i++){
      printf("Soma: %d\n", soma[i]);
  }

}

