#include <stdio.h>

// Autor : Andre  Martinotto
// Data : 13/08/2018
#define N 4

void main(){
  int mat[4][4];
  int i, j, soma, diagonal, dominante, maior;
  
  for(i=0; i<4; i++){
      for(j=0; j<4; j++){
          printf("Digite o valor:\n");
          scanf("%d", &mat[i][j]);
      }
  }
    
  diagonal = 1;
  maior = 0;
  
  for(i=0; i<4; i++){
      soma = 0;
      for(j=0; j<4; j++){
          if ( i!= j){
              soma += mat[i][j];
          }
      }
      if ( mat[i][i] < soma ){
          diagonal = 0;
      }
      if ( mat[i][i] > soma){
          maior++;
      }
  }      
   
  if ( diagonal && maior ){
      dominante = 1;
  }
  else{
      dominante = 0;
  }
  
  printf("Diagonal Dominante: %d\n", dominante);
 
}




