#include <stdio.h>
#include <stdlib.h>

//-------------------------------------------------------------
#define N 5

//-------------------------------------------------------------
void le_matriz(int mat[N][N]){
	int i, j;
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			printf("Digite o valor:\n");
			scanf("%d", &mat[i][j]);
		}
	}
}
//-------------------------------------------------------------
void escreve_matriz(int mat[N][N]){
	int i, j;
    printf("------------------------------\n");
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			printf("% 4d", mat[i][j]);
		}
		printf("\n");
	}
}
//-------------------------------------------------------------
void ordena_matriz(int mat[N][N]){
	int i, j, k, aux;

	for(i=0; i<N-1; i++){
		for(j=0; j<N-1; j++){
            if ( abs(mat[j][0]) < abs(mat[j+1][0]) ){
                for(k=0; k<N; k++){
                    aux = mat[j][k];
                    mat[j][k] = mat[j+1][k];
                    mat[j+1][k] = aux;
                }
            }
		}
	}
}

//-------------------------------------------------------------
int main(){
	int mat[N][N];
	le_matriz(mat);
	escreve_matriz(mat);
    ordena_matriz(mat);
    escreve_matriz(mat);	
}
