#include <stdio.h>
#include <math.h>

//-------------------------------------------------------------
#define N 5

//-------------------------------------------------------------
void le_matriz(int mat[N][N]){
	int i, j;
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			printf("Digite o valor:\n");
			scanf("%d", &mat[i][j]);
		}
	}
}

//-------------------------------------------------------------
void escreve_matriz(int mat[N][N]){
	int i, j;
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			printf("% 4d", mat[i][j]);
		}
		printf("\n");
	}
}

//-------------------------------------------------------------
int quadrado_magico(int mat[N][N]){
	int i, j, soma, s;
	
	soma = 0;
	for(i=0; i<N; i++){
		soma += mat[i][j];
	}
	
	s = 0;
	for(i=0, j=N-1; i<N; i++, j--){
		s += mat[i][j]; 
	}
	if ( s != soma ){
		return 0;
	}
	
	for(i=0; i<N; i++){
		s = 0;
		for(j=0; j<N; j++){
			s += mat[i][j];
		}
		if ( s != soma ){
			return 0;
		}
	}
	
	for(j=0; j<N; j++){
		s = 0;
		for(i=0; i<N; i++){
			s += mat[i][j];
		}
		if ( s != soma ){
			return 0;
		}
	}
	
	return 1;
	
}

//-------------------------------------------------------------
int main(){
	int mat[N][N];
	le_matriz(mat);
	escreve_matriz(mat);	
	printf("Quadrado Magico: %d\n", quadrado_magico(mat));
}
