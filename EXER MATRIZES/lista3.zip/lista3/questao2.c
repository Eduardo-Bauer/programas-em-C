#include <stdio.h>
#include <math.h>

//-------------------------------------------------------------
#define N 5

//-------------------------------------------------------------
void le_matriz(int mat[N][N]){
	int i, j;
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			printf("Digite o valor:\n");
			scanf("%d", &mat[i][j]);
		}
	}
}
//-------------------------------------------------------------
void escreve_matriz(int mat[N][N]){
	int i, j;
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			printf("% 4d", mat[i][j]);
		}
		printf("\n");
	}
}
//-------------------------------------------------------------
int tipo_matriz(int mat[N][N]){
    int i, j;
    int diagonal = 0;
    int superior = 0;
    int inferior = 0;

    for(i=0; i<N; i++){
        for(j=0; j<N; j++){
            if ( i==j && mat[i][j]!=0){
                diagonal++;
            }
            else if ( i < j && mat[i][j]!=0){
                superior++;
            }
            else if ( i > j && mat[i][j]!=0){
                inferior++;
            }
        }
    }

    if ( inferior > 0 && diagonal == 0  && superior == 0){
        return 1;
    }
    else if ( superior > 0 && diagonal == 0 && inferior == 0){
        return 2;
    }
    else if ( diagonal > 0 && superior == 0 && inferior == 0){
        return 3;
    }
    else {
        return 0;
    }


}
//-------------------------------------------------------------
int main(){
	int mat[N][N];
	le_matriz(mat);
	escreve_matriz(mat);	
    printf("Tipo da matriz: %d\n", tipo_matriz(mat));
}
