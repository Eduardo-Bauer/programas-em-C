#include <stdio.h>
#include <math.h>

//-------------------------------------------------------------
#define N 5

//-------------------------------------------------------------
int primo(int n){
	int i;
	if ( n < 2 ){
		return 0;
	}
	for(i=2; i<=sqrt(n); i++){
		if ( n % i == 0){
			return 0;
		}
	}
	
	return 1;
}
//-------------------------------------------------------------
int quantidade_primos(int mat[N][N]){
	int i, j;
	int abaixo = 0, acima = 0;
	
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			if ( primo(mat[i][j]) ){
				if ( i+j < N-1 ){
					acima++;
				}
				else if ( i+j > N-1 ){
					abaixo++;
				}
			}	
		}
	}
	
	if ( acima == abaixo ){
		return 0;
	}
	else if ( acima > abaixo ){
		return -1;
	}
	else{
		return 1;
	}
	
}
//-------------------------------------------------------------
void le_matriz(int mat[N][N]){
	int i, j;
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			printf("Digite o valor:\n");
			scanf("%d", &mat[i][j]);
		}
	}
}
//-------------------------------------------------------------
void escreve_matriz(int mat[N][N]){
	int i, j;
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			printf("% 4d", mat[i][j]);
		}
		printf("\n");
	}
}
//-------------------------------------------------------------
int main(){
	int mat[N][N];
	le_matriz(mat);
	escreve_matriz(mat);	
	printf("Primos: %d\n", quantidade_primos(mat));
}
