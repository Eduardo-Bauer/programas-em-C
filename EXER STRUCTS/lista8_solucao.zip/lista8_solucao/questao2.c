#include <stdio.h>
#include <string.h>

/*----------------------------------------------------*/
#define N 6

/*----------------------------------------------------*/
struct carro {
	char fabricante[50];
	char modelo[10];
    float preco;
};
typedef struct carro CARRO;

/*----------------------------------------------------*/
void le_carros(CARRO vetor[N]){
	int i;

	for(i=0; i<N; i++){
		printf("Digite o fabricante:\n");
		gets(vetor[i].fabricante);
   		printf("Digite o fabricante:\n");
		gets(vetor[i].modelo);
	    printf("Digite o preco:\n");
        scanf("%f", &vetor[i].preco);
		getchar();
	}
}
/*----------------------------------------------------*/
void ordena_carros(CARRO vetor[N]){
	
	int i, j;
    CARRO aux;

	for(i=0; i<N-1; i++){
	   for(j=0; j<N-1-i; j++){ 
		if ( (strcasecmp(vetor[j].fabricante,vetor[j+1].fabricante)>0) ||
             (strcasecmp(vetor[j].fabricante,vetor[j+1].fabricante)==0 && vetor[j].preco>vetor[j+1].preco)||
             (strcasecmp(vetor[j].fabricante,vetor[j+1].fabricante)==0 && vetor[j].preco==vetor[j+1].preco && strcasecmp(vetor[j].modelo,vetor[j+1].modelo)>0)){
	   	   aux = vetor[j];
		   vetor[j] = vetor[j+1];
	 	   vetor[j+1] = aux;
		} 
	   }
	}
}
/*----------------------------------------------------*/
void escreve_carros(CARRO vetor[N]){
	int i;
	for(i=0; i<N; i++){
		printf("%s %s %.2f\n", vetor[i].fabricante, vetor[i].modelo, vetor[i].preco);
	}
}

/*----------------------------------------------------*/
int main(){
	CARRO vetor[N];
	le_carros(vetor);
	ordena_carros(vetor);
	escreve_carros(vetor);
}
/*----------------------------------------------------*/
