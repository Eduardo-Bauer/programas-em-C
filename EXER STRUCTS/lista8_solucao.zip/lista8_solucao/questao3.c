#include <stdlib.h>
#include <stdio.h>

/*---------------------------------------------------------------*/
#define N 6

/*---------------------------------------------------------------*/
struct data {
	int dia;
	int mes;
	int ano;
};
typedef struct data DATA;

struct livro {
	char titulo[50];
    char autor[50];	
    DATA edicao;
};
typedef struct livro LIVRO;

/*---------------------------------------------------------------*/
void le_livros(LIVRO vetor[N]){
	
    int i;
	for(i=0; i<N; i++){
		printf("Digite o titulo:\n");
        gets(vetor[i].titulo);
		printf("Digite o autor:\n");
        gets(vetor[i].autor);
        printf("Digite a data de edicao:\n");
        scanf("%d %d %d", &vetor[i].edicao.dia, &vetor[i].edicao.mes, &vetor[i].edicao.ano);
        getchar();
    }	
}

/*---------------------------------------------------------------*/
void escreve_livros(LIVRO vetor[N]){
	
    int i;
	for(i=0; i<N; i++){
		printf("%s\n", vetor[i].titulo);
        printf("%s\n", vetor[i].autor);
        printf("%d %d %d\n", vetor[i].edicao.dia, vetor[i].edicao.mes, vetor[i].edicao.ano);
    }	
}

/*---------------------------------------------------------------*/
void mais_novo_antigo(LIVRO vetor[N]){
    	
    LIVRO mantigo = vetor[0];
    LIVRO mnovo = vetor[0];
    
    float atual;
    int i;

    float antigo = vetor[0].edicao.ano * 10000 + vetor[0].edicao.mes * 100 + vetor[0].edicao.dia;
    float novo = vetor[0].edicao.ano * 10000 + vetor[0].edicao.mes * 100 + vetor[0].edicao.dia;
    

    for(i=1; i<N; i++){
        atual =  vetor[i].edicao.ano * 10000 + vetor[i].edicao.mes * 100 + vetor[i].edicao.dia;

        if ( atual < antigo ){
            mantigo = vetor[i];
            antigo = atual;
        }

        if ( atual > novo ){
            mnovo = vetor[i];
            novo = atual;
        }
    } 

    printf("\nLivro Mais Novo\n");
    printf("Titulo: %s\n", mnovo.titulo);
    printf("Autor: %s\n", mnovo.autor);
    printf("Edicao: %d/%d/%d\n", mnovo.edicao.dia, mnovo.edicao.mes, mnovo.edicao.ano);
 
    
    printf("\nLivro Mais Antigo\n");
    printf("Titulo: %s\n", mantigo.titulo);
    printf("Autor: %s\n", mantigo.autor);
    printf("Edicao: %d/%d/%d\n", mantigo.edicao.dia, mantigo.edicao.mes, mantigo.edicao.ano);
}

/*---------------------------------------------------------------*/
int main(){

	LIVRO vetor[N];
    
    le_livros(vetor);
    //escreve_livros(vetor);
    mais_novo_antigo(vetor);
}
/*---------------------------------------------------------------*/

