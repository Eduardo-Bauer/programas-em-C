#include <stdlib.h>
#include <stdio.h>

/*---------------------------------------------------------------*/
#define N 6

/*---------------------------------------------------------------*/
struct data {
	int dia;
	int mes;
	int ano;
};
typedef struct data DATA;

struct funcionario {
	int codigo;
	char nome[100];
	DATA nasc;
    float valor_hora;
};
typedef struct funcionario FUNCIONARIO;

/*---------------------------------------------------------------*/
void le_funcionarios(FUNCIONARIO vetor[N]){
	
    int i;
	for(i=0; i<N; i++){
		printf("Digite o codigo do funcionario:\n");
        scanf("%d", &vetor[i].codigo);
        getchar();
        printf("Digite o nome:\n");
        gets(vetor[i].nome);
        printf("Digite a data de nascimento:\n");
        scanf("%d %d %d", &vetor[i].nasc.dia, &vetor[i].nasc.mes, &vetor[i].nasc.ano);
        printf("Digite o valor hora:\n");
        scanf("%f", &vetor[i].valor_hora);
    }	
}
/*---------------------------------------------------------------*/
void escreve_funcionarios(FUNCIONARIO vetor[N]){
	
    int i;
	for(i=0; i<N; i++){
		printf("%d\n", vetor[i].codigo);
        printf("%s\n", vetor[i].nome);
        printf("%d %d %d\n", vetor[i].nasc.dia, vetor[i].nasc.mes, vetor[i].nasc.ano);
        printf("%f\n", vetor[i].valor_hora);
    }	
}

/*---------------------------------------------------------------*/
FUNCIONARIO mais_velho(FUNCIONARIO vetor[N]){
    	
    FUNCIONARIO mvelho = vetor[0];
    float atual, menor = vetor[0].nasc.ano * 10000 + vetor[0].nasc.mes * 100 + vetor[0].nasc.dia;
    int i;

   	for(i=1; i<N; i++){
        atual = vetor[i].nasc.ano * 10000 + vetor[i].nasc.mes * 100 + vetor[i].nasc.dia;
        if ( atual < menor ){
            menor = atual;
            mvelho = vetor[i];        
        }
    }
    return mvelho;
}

/*---------------------------------------------------------------*/
int main(){

	FUNCIONARIO vetor[N];
    FUNCIONARIO mvelho;

    le_funcionarios(vetor);
    mvelho = mais_velho(vetor);    
    
	printf("Codigo: %d\n", mvelho.codigo);
    printf("Nome: %s\n", mvelho.nome);
    printf("Data de Nascimento: %d/%d/%d\n", mvelho.nasc.dia, mvelho.nasc.mes, mvelho.nasc.ano);
    printf("Valor Hora: R$ %.2f\n", mvelho.valor_hora);	
    
}
/*---------------------------------------------------------------*/

