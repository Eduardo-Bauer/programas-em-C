#include<stdio.h>
#include <stdlib.h>
#include<math.h>

#define N 10

/*----------------------------------------------------*/
struct ponto{
	float x;
	float y;
};
typedef struct ponto PONTO;

/*----------------------------------------------------*/
float distancia(PONTO p1, PONTO p2){
	return( sqrt((p2.x - p1.x)*(p2.x - p1.x)+ (p2.y - p1.y)*(p2.y - p1.y)));
}

/*----------------------------------------------------*/
void le_pontos(PONTO vetor[N]){
	int i;
	for( i=0; i<N; i++ ){
	    printf("Digite o ponto:\n");
	    scanf("%f %f", &vetor[i].x, &vetor[i].y); 	
	}
}

/*----------------------------------------------------*/
PONTO mais_distante_ponto_medio (PONTO vetor[N]){

	int i, j, cont;
	float soma_x, soma_y, dist, maior;
    PONTO centro, pdist;

    cont = 0;
    soma_x = 0;
    soma_y = 0;
	for(i=0; i<N; i++){
        soma_x += vetor[i].x;
        soma_y += vetor[i].y;
    }

    centro.x = soma_x/N;
    centro.y = soma_y/N;

    maior = 0;
   	for(i=0; i<N; i++){
        dist = distancia(vetor[i], centro); 
	    if (  dist > maior){
            maior = dist;
            pdist = vetor[i];
        }
    }   
    return pdist;
}

/*----------------------------------------------------*/
int main(){
	PONTO vetor[N], pdist;
	
	le_pontos(vetor);
    pdist = mais_distante_ponto_medio(vetor);
    printf("(%.1f,%.1f)\n", pdist.x, pdist.y);
}
/*----------------------------------------------------*/


