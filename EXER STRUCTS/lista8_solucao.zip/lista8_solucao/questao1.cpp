#include <stdio.h>
#include <string.h>

/*----------------------------------------------------*/
#define N 500

/*----------------------------------------------------*/
struct camiseta{
	char nome[50];
	char cor[10];
    char tam;
};
typedef struct camiseta CAMISETA;

/*----------------------------------------------------*/
int le_camisetas(CAMISETA vetor[N]){
	int i, n;

    printf("Digite o numero de camisetas:\n");
    scanf("%d", &n);
    getchar();

	for(i=0; i<n; i++){
		printf("Digite o nome:\n");
		gets(vetor[i].nome);
		printf("Digite a cor e o tamanho:\n");
        scanf("%s %c", vetor[i].cor, &vetor[i].tam);
		getchar();
	}

}
/*----------------------------------------------------*/
void ordena_camisetas(CAMISETA vetor[N], int n){
	
	int i, j;
	CAMISETA aux;
	
	for(i=0; i<n-1; i++){
	   for(j=0; j<n-1-i; j++){ 
		if ( (strcasecmp(vetor[j].cor,vetor[j+1].cor)>0) ||
             (strcasecmp(vetor[j].cor,vetor[j+1].cor)==0 && vetor[j].tam<vetor[j+1].tam ) ||
             (strcasecmp(vetor[j].cor,vetor[j+1].cor)==0 && vetor[j].tam==vetor[j+1].tam && strcasecmp(vetor[j].nome,vetor[j+1].nome)>0)){                 
	   	   aux = vetor[j];
		   vetor[j] = vetor[j+1];
	 	   vetor[j+1] = aux;
		} 
	   }
	}
}
/*----------------------------------------------------*/
void escreve_camisetas(CAMISETA vetor[N], int n){
	int i;
	for(i=0; i<n; i++){
		printf("%s %c %s\n", vetor[i].cor, vetor[i].tam, vetor[i].nome);
	}
}

/*----------------------------------------------------*/
int main(){
	CAMISETA vetor[N];
	int n = le_camisetas(vetor);
	ordena_camisetas(vetor, n);
	escreve_camisetas(vetor, n);
}
/*----------------------------------------------------*/
