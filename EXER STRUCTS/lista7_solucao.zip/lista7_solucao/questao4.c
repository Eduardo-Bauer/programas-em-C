#include <stdio.h>
#include <string.h>

/*----------------------------------------------------*/
#define N 6

/*----------------------------------------------------*/
struct pessoa{
	char nome[50];
	int peso;
	float altura;
	float imc;
};
typedef struct pessoa PESSOA;

/*----------------------------------------------------*/
void le_pessoas(PESSOA vetor[N]){
	int i;
	for(i=0; i<N; i++){
		printf("Digite o nome da pessoa:\n");
		gets(vetor[i].nome);
		printf("Digite o peso:\n");
		scanf("%d", &vetor[i].peso);
		printf("Digite a altura:\n");
		scanf("%f", &vetor[i].altura);
		vetor[i].imc  = vetor[i].peso/(vetor[i].altura*vetor[i].altura);  
		getchar();
	}
}
/*----------------------------------------------------*/
void ordena_pessoas(PESSOA vetor[N]){
	
	int i, j;
	PESSOA aux;
	
	for(i=0; i<N-1; i++){
	   for(j=0; j<N-1-i; j++){ 
		if ( vetor[j].imc < vetor[j+1].imc ){ 
	   	   aux = vetor[j];
		   vetor[j] = vetor[j+1];
	 	   vetor[j+1] = aux;
		} 
	   }
	}
}
/*----------------------------------------------------*/
void escreve_pessoas(PESSOA vetor[N]){
	int i;
	for(i=0; i<N; i++){
		printf("%s\n", vetor[i].nome);
		printf("%.2f\n", vetor[i].imc);
	}
}

/*----------------------------------------------------*/
int main(){
	PESSOA vetor[N];
	le_pessoas(vetor);
	ordena_pessoas(vetor);
	escreve_pessoas(vetor);
}
/*----------------------------------------------------*/
