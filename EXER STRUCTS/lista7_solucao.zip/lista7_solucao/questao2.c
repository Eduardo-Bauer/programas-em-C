#include <stdio.h>

/*----------------------------------------------------*/
#define N 5

/*----------------------------------------------------*/
struct hora {
     int hora;
     int minutos;
     int segundos;
};
typedef struct hora HORA;

/*----------------------------------------------------*/
HORA adiciona_segundo(HORA atual){
	int total = ((atual.hora*3600 + atual.minutos*60 + atual.segundos) + 1) % 86400;
	atual.hora = total / 3600;
	total %= 3600;
	atual.minutos = total / 60;
	atual.segundos = total % 60;
	return atual;
}
/*----------------------------------------------------*/
int main(){
	HORA atual, proximo;
	int i;
	
	for(i=0; i<N; i++){
		printf("Digite a hora atual:\n");
		scanf("%d %d %d", &atual.hora, &atual.minutos, &atual.segundos);
		proximo = adiciona_segundo(atual);
		printf("Proximo segundo: %d/%d/%d\n", proximo.hora, proximo.minutos, proximo.segundos);
	}
}
