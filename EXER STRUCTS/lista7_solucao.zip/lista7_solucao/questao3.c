#include <stdio.h>
#include <string.h>

/*----------------------------------------------------*/
#define N 6

/*----------------------------------------------------*/
struct aluno{
	char nome[50];
	float n1;
	float n2;
	float n3;
	float m;
};
typedef struct aluno ALUNO;

/*----------------------------------------------------*/
void le_alunos(ALUNO vetor[N]){
	int i;
	for(i=0; i<N; i++){
		printf("Digite o nome do aluno:\n");
		gets(vetor[i].nome);
		printf("Digite as 3 notas do aluno:\n");
		scanf("%f %f %f", &vetor[i].n1, &vetor[i].n2, &vetor[i].n3);
		vetor[i].m = (vetor[i].n1 + vetor[i].n2 + vetor[i].n3)/3;
		getchar();
	}
}
/*----------------------------------------------------*/
void ordena_alunos(ALUNO vetor[N]){
	
	int i, j;
	ALUNO aux;
	
	for(i=0; i<N-1; i++){
	   for(j=0; j<N-1-i; j++){ 
		if ( vetor[j].m < vetor[j+1].m || ( vetor[j].m == vetor[j+1].m && strcasecmp(vetor[j].nome, vetor[j+1].nome)>0)){ 
	   	   aux = vetor[j];
		   vetor[j] = vetor[j+1];
	 	   vetor[j+1] = aux;
		} 
	   }
	}
}
/*----------------------------------------------------*/
void escreve_alunos(ALUNO vetor[N]){
	int i;
	for(i=0; i<N; i++){
		printf("%s %.1f\n", vetor[i].nome, vetor[i].m);
	}
}

/*----------------------------------------------------*/
int main(){
	ALUNO vetor[N];
	le_alunos(vetor);
	ordena_alunos(vetor);
	escreve_alunos(vetor);
}
/*----------------------------------------------------*/
