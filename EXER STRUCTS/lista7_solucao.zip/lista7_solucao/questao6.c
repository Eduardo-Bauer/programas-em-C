#include <stdio.h>
#include <string.h>

/*----------------------------------------------------*/
#define N 6

/*----------------------------------------------------*/
struct candidato{
	char nome[50];
	int partido;
    int votos;
};
typedef struct candidato CANDIDATO;

/*----------------------------------------------------*/
void le_candidatos(CANDIDATO vetor[N]){
	int i;
	for(i=0; i<N; i++){
		printf("Digite o nome do candidato:\n");
		gets(vetor[i].nome);
		printf("Digite o partido:\n");
		scanf("%d", &vetor[i].partido);
   		printf("Digite o numero de votos:\n");
		scanf("%d", &vetor[i].votos);
		getchar();
	}
}
/*----------------------------------------------------*/
void ordena_candidatos(CANDIDATO vetor[N]){
	
	int i, j;
	CANDIDATO aux;
	
	for(i=0; i<N-1; i++){
	   for(j=0; j<N-1-i; j++){ 
		if ( vetor[j].partido > vetor[j+1].partido || ( vetor[j].partido == vetor[j+1].partido && vetor[j].votos < vetor[j+1].votos)){ 
	   	   aux = vetor[j];
		   vetor[j] = vetor[j+1];
	 	   vetor[j+1] = aux;
		} 
	   }
	}
}
/*----------------------------------------------------*/
void escreve_candidatos(CANDIDATO vetor[N]){
	int i;
	for(i=0; i<N; i++){
		printf("%s %d %d\n", vetor[i].nome, vetor[i].partido, vetor[i].votos);
	}
}

/*----------------------------------------------------*/
int main(){
	CANDIDATO vetor[N];
	le_candidatos(vetor);
	ordena_candidatos(vetor);
	escreve_candidatos(vetor);
}
/*----------------------------------------------------*/
