#include <stdio.h>

/*----------------------------------------------------*/
#define N 5

/*----------------------------------------------------*/
struct data {
     int dia;
     int mes;
     int ano;
};
typedef struct data DATA;

/*----------------------------------------------------*/
int bissexto(int ano){
	if ( (ano%4==0 && ano%100!=0) || ano%400==0){
		printf("bissexto\n");
		return 1;
	}
	else{
		return 0;
	}
}

/*----------------------------------------------------*/
DATA proximo_dia (DATA atual){

	if (atual.dia == 31 && atual.mes == 12 ){
		atual.dia = 1;
		atual.mes = 1;
		atual.ano++;
	}
	else if ( atual.dia == 31 && ( atual.mes==1 || atual.mes==3 || atual.mes==5 || atual.mes==7 || atual.mes==8 || atual.mes==10)){
		atual.dia = 1;
		atual.mes++;
	}
	else if ( atual.dia == 30 && ( atual.mes==4 || atual.mes==6 || atual.mes==9 || atual.mes==11) ){
		atual.dia = 1;
		atual.mes++;
	}
	else if ( atual.dia == 29 && atual.mes == 2 && bissexto(atual.ano)){
		atual.dia = 1;
		atual.mes++;
	}
	else if ( atual.dia == 28 && atual.mes == 2 && !bissexto(atual.ano)){
		atual.dia = 1;
		atual.mes++;
	}
	else{
		atual.dia++;
	}
	return atual;
}
/*----------------------------------------------------*/
int main(){
	DATA atual, proximo;
	int i;
	
	for(i=0; i<N; i++){
		printf("Digite a data atual:\n");
		scanf("%d %d %d", &atual.dia, &atual.mes, &atual.ano);
		proximo = proximo_dia(atual);
		printf("Proximo: %d/%d/%d\n", proximo.dia, proximo.mes, proximo.ano );
	}
}
