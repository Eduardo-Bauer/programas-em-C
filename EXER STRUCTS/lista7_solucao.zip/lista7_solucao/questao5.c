#include <stdio.h>
#include <string.h>

/*----------------------------------------------------*/
#define N 8

/*----------------------------------------------------*/
struct cliente{
	char nome[50];
	float fat;
};
typedef struct cliente CLIENTE;

/*----------------------------------------------------*/
void le_clientes(CLIENTE vetor[N]){
	int i;
	for(i=0; i<N; i++){
		printf("Digite o nome do aluno:\n");
		gets(vetor[i].nome);
		printf("Digite o faturamento:\n");
		scanf("%f", &vetor[i].fat);
		getchar();
	}
}

/*----------------------------------------------------*/
void ordena_clientes(CLIENTE vetor[N]){
	
	int i, j;
	CLIENTE aux;
	
	for(i=0; i<N-1; i++){
	   for(j=0; j<N-1-i; j++){ 
		if ( vetor[j].fat < vetor[j+1].fat ){ 
	   	   aux = vetor[j];
		   vetor[j] = vetor[j+1];
	 	   vetor[j+1] = aux;
		} 
	   }
	}
}
/*----------------------------------------------------*/
float total_faturamento(CLIENTE vetor[N]){
	int i;
	float total = 0;
	for(i=0; i<N; i++){
		total += vetor[i].fat;
	}
	return total;
}
/*----------------------------------------------------*/
void escreve_saida(CLIENTE vetor[N]){
	
	float soma, total;
	int i,  cont;
	
	total = total_faturamento(vetor);
	
	cont = 0;
	soma = 0;
	while ( soma < total/2 ){
		soma += vetor[cont].fat;
		cont++;
	}
	
	printf("Total faturado: %.2f\n", total);
	printf("Numero de Clientes: %d\n", cont);
	for(i=0; i<cont; i++){
		printf("%s %.2f\n", vetor[i].nome, vetor[i].fat);
	}
}

/*----------------------------------------------------*/
int main(){
	CLIENTE vetor[N];
	le_clientes(vetor);
	ordena_clientes(vetor);
	escreve_saida(vetor);
}
/*----------------------------------------------------*/
