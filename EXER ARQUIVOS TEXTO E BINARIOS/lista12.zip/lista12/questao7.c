#include<stdio.h>
#include<stdlib.h>

/*---------------------------------------------------------------------------*/
struct data {
     int dia;
     int mes;
     int ano;
};
typedef struct data DATA;

struct funcionario {
     int codigo;
     char nome[50];
     DATA nascimento;
     float valor_hora;
};
typedef struct funcionario FUNCIONARIO;


/*---------------------------------------------------------------------------*/
void escreve_funcionarios(char arquivo[50]){
	FILE *f = fopen(arquivo, "rb");
	FUNCIONARIO aux;
	while ( fread(&aux, sizeof(FUNCIONARIO), 1, f) ){
		printf("Codigo: %d Nome: %s Salario: %.2f\n", aux.codigo, aux.nome, aux.valor_hora); 
	}
	fclose(f);
}
/*---------------------------------------------------------------------------*/
void atualiza_valor_hora(char arquivo[50], int codigo, float novo_valor_hora){
	FILE *f = fopen(arquivo, "rb+");
	FUNCIONARIO aux;

	while ( fread(&aux, sizeof(FUNCIONARIO), 1, f) ){
		if ( aux.codigo == codigo ){
			aux.valor_hora = novo_valor_hora;
			fseek(f, -1*sizeof(FUNCIONARIO), SEEK_CUR);
			fwrite(&aux, sizeof(FUNCIONARIO), 1, f);
			break;
		}	
	}
	if ( feof(f) ){
		printf("Codigo Inexistente\n");
	}
	fclose(f);
}

/*---------------------------------------------------------------------------*/
int main(){
	char arquivo[50];
	int codigo;
	float novo_valor_hora;
	
	printf("Digite o nome do arquivo:\n");
	scanf("%s", arquivo);
	
	printf("Digite o codigo do funcionario:\n");
	scanf("%d", &codigo);
	
	printf("Digite o novo valor hora:\n");
	scanf("%f", &novo_valor_hora);
		
	atualiza_valor_hora(arquivo, codigo, novo_valor_hora);
	
	escreve_funcionarios(arquivo);
		
}

/*---------------------------------------------------------------------------*/
