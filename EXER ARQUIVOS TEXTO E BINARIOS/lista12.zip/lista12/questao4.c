#include <stdio.h>
#include <stdlib.h>
#include <math.h>

/*---------------------------------------------------------*/
struct ponto{
	float x;
	float y;
};
typedef struct ponto PONTO;
/*---------------------------------------------------------*/
PONTO mais_distante_ponto_medio (char arquivo[50]){

	FILE *f = NULL;

	PONTO p, distante;
	float somax, somay;
	float mediax, mediay;
	float maior_distancia, dist;
	int cont;

	f = fopen(arquivo,"rb");

	if ( f == NULL ){
		printf("Erro ao abrir o arquivo %s\n", arquivo);
		exit(0);
	}

	somax= 0;
	somay= 0;
	cont = 0;
	while ( fread(&p, sizeof(PONTO), 1, f ) ){
		somax += p.x;
		somay += p.y;
		cont++;
	}

	mediax = somax/cont;
	mediay = somay/cont;

	printf("Centro Medio: (%.2f, %.2f)\n", mediax, mediay);

	rewind(f);

	maior_distancia = 0;
	
	while ( fread(&p, sizeof(PONTO), 1, f ) ){

		dist = sqrt( (p.x-mediax)*(p.x-mediax) + (p.y-mediay)*(p.y-mediay) );

		if ( dist > maior_distancia ){
			maior_distancia = dist;
			distante = p;
		}
	}

	fclose(f);

	return distante;
}
/*---------------------------------------------------------*/
int main(){
	char entrada[50];

	printf("Digite o nome do arquivo de entrada:\n");
	scanf("%s", entrada);

	PONTO distante = mais_distante_ponto_medio(entrada);

	printf("Mais distante: (%.2f, %.2f)\n", distante.x, distante.y);
}
/*---------------------------------------------------------*/
