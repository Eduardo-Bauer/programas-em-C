#include <stdio.h>
#include <stdlib.h>

/*----------------------------------------------------------*/
void escreve_arquivo(char arquivo[50]){
	int aux;

	FILE *f = fopen(arquivo,"rb");

	if ( f == NULL ){
		printf("Erro ao abrir o arquivo\n");
		exit(0);
	}

	while ( fread(&aux, sizeof(int), 1, f) ){
		printf("%d\n", aux);
	}

	fclose(f);
}


/*----------------------------------------------------------*/
void insere_valor(char arquivo[50], int n){
	int aux;
	
	FILE *f = fopen(arquivo,"rb+");
	
	if ( f == NULL ){
		printf("Erro ao abrir o arquivo %s\n", arquivo);
		exit(0);
	}
	
	while ( fread(&aux, sizeof(int), 1, f ) ){
		if ( n < aux){
			break;
		} 
	}  
	
	if ( feof(f) ){
		fwrite(&n, sizeof(int), 1, f);
	}
	else{
		do{
			fseek(f, -1*sizeof(int), SEEK_CUR);
			fwrite(&n, sizeof(int), 1, f);
			n = aux;
		}
		while( fread(&aux, sizeof(int), 1, f) );
		fwrite(&n, sizeof(int), 1, f);
	}
	fclose(f);
}

/*----------------------------------------------------------*/
int main(){
	char arquivo[50];
	
	printf("Digite o nome do arquivo:\n");
	scanf("%s", arquivo);
	
	printf("--------------------------------------\n");
	escreve_arquivo(arquivo);
	printf("--------------------------------------\n");
	insere_valor(arquivo, 40);	
	insere_valor(arquivo, 48);	
	insere_valor(arquivo, 70);	
	
	printf("--------------------------------------\n");
	escreve_arquivo(arquivo);
	printf("--------------------------------------\n");
}
/*----------------------------------------------------------*/

