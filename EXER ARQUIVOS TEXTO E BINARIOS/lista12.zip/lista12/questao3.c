#include <stdio.h>
#include <stdlib.h>

/*--------------------------------------------*/
struct estado{
	char nome[31];
	int numveic;
	int numacid;
};
typedef struct estado ESTADO;
/*--------------------------------------------*/
ESTADO estado_maior_numero_acidentes(char arquivo[50]){
	
	FILE *f = NULL;
	ESTADO aux,  maior;

	f = fopen(arquivo,"rb");

	if ( f == NULL ){
		printf("Erro ao abrir o arquivo %s\n", arquivo);
		exit(0);
	}

	maior.numacid = 0;
	while ( fread(&aux, sizeof(ESTADO), 1, f) > 0 ) {
		if ( aux.numacid > maior.numacid ){
			maior = aux;
		}
	}	
	fclose(f);
	return maior;
}


/*--------------------------------------------*/
void main(){
	char arquivo[50];

	printf("Digite o nome do arquivo:\n");
	scanf("%s", arquivo);

	ESTADO maior = estado_maior_numero_acidentes(arquivo);

	printf("Estado: %s\n", maior.nome);
	printf("Numero de Acidentes: %d\n", maior.numacid);
}
/*--------------------------------------------*/




