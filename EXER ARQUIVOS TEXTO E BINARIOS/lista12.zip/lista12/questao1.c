#include <stdio.h>
#include <stdlib.h>

int main(){
	char arquivo[50];
	FILE *f;
	float soma, media, n, menor;
	int cont;

	printf("Digite o nome do arquivo de entrada:\n");
	scanf("%s", arquivo);

	f = fopen(arquivo, "rb");

	if ( f == NULL ){
		printf("Erro ao abrir o arquivo %s\n", arquivo);
		exit(0);
	}

	soma = 0;
	cont = 0;
	while ( fread(&n, sizeof(float), 1, f) ){
		soma += n;
		cont++;
	}
	media = soma / cont;

	rewind(f);

	menor = 0;
	cont = 0;
	while ( fread(&n, sizeof(float), 1, f) ){
		if ( n >= menor){
			if ( n<menor || cont == 0 ){
				menor = n;
				cont = 1;
			}	
		}
	}

	printf("Menor: %f\n", menor);

	fclose(f);

}
