#include <stdio.h>
#include <stdlib.h>


/*---------------------------------------------------------*/
struct data{
	int d, m, a;
};
typedef struct data DATA;

struct livro{
    char nome[50];
    char autor[50];
    DATA nasc;
};
typedef struct livro LIVRO;

/*---------------------------------------------------------*/
void livro_antigo_novo(char arquivo[50], LIVRO *antigo, LIVRO *novo){

	LIVRO aux;
	int flag = 0;
	FILE *f = fopen(arquivo,"rb");

	if ( f == NULL ){
		printf("Erro ao abrir o arquivo %s\n", arquivo);
		exit(0);
	}

	while(fread(&aux, sizeof(LIVRO), 1, f) ){
		
		if (!flag){
			*antigo = aux;
			*novo = aux;
			flag = 1;
		}

		if ( aux.nasc.a*10000 + aux.nasc.m*100 + aux.nasc.d < antigo->nasc.a*10000 + antigo->nasc.m*100 + antigo->nasc.d){
			*antigo = aux;
		}

		if ( aux.nasc.a*10000 + aux.nasc.m*100 + aux.nasc.d > novo->nasc.a*10000 + novo->nasc.m*100 + novo->nasc.d){
			*novo = aux;
		}
	}

	fclose(f);
	
}

/*---------------------------------------------------------*/
int main(){

	char entrada[50];
	LIVRO antigo, novo;

	printf("Digite o nome do arquivo de entrada:\n");
	scanf("%s", entrada);

 	livro_antigo_novo(entrada, &antigo, &novo);

	printf("Livro Mais Antigo\n");
	printf("Título: %s\n", antigo.nome);
	printf("Autor: %s\n", antigo.autor);
	printf("Edicao: %d/%d/%d\n", antigo.nasc.d, antigo.nasc.m, antigo.nasc.a);

	printf("Livro Mais Novo\n");
	printf("Título: %s\n", novo.nome);
	printf("Autor: %s\n", novo.autor);
	printf("Edicao: %d/%d/%d\n", novo.nasc.d, novo.nasc.m, novo.nasc.a);

}
/*---------------------------------------------------------*/

