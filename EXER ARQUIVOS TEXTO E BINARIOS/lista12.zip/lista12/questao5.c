#include <stdio.h>
#include <stdlib.h>

/*---------------------------------------------------------*/
struct alunos{
    char nome[50];
    float n1, n2, n3;
};
typedef struct alunos ALUNOS;

/*---------------------------------------------------------*/
ALUNOS *le_dados_alunos(char arquivo[50], int *num_alunos){

	int i, cont;
	ALUNOS aux, *vet = NULL;

	FILE *f = fopen(arquivo,"rb");

	if ( f == NULL ){
		printf("Erro ao abrir o arquivo %s\n", arquivo);
		exit(0);
	}

	cont  = 0;
	while ( fread(&aux, sizeof(ALUNOS), 1, f) ){
		cont++;
	}

	vet = (ALUNOS *)malloc(cont * sizeof(ALUNOS) );

	rewind(f);

	for(i=0; i<cont; i++){
		fread(&vet[i], sizeof(ALUNOS), 1, f);
	}

	fclose(f);

	*num_alunos = cont;
	return vet;
}
/*---------------------------------------------------------*/
void ordena_alunos(ALUNOS *vet, int num_alunos){
	int i, j;
	float m1, m2;
	ALUNOS aux;

	for(i=0; i<num_alunos-1; i++){
		for(j=0; j<num_alunos-1-i; j++){
			m1 = (vet[j].n1 + vet[j].n2 + vet[j].n3)/3;
			m2 = (vet[j+1].n1 + vet[j+1].n2 + vet[j+1].n3)/3;
			if ( m1 < m2 ){
				aux = vet[j];
				vet[j] = vet[j+1];
				vet[j+1] = aux;
			}
		}
	}
}

/*---------------------------------------------------------*/
void gera_arquivo_alunos(char arquivo[50], ALUNOS *vet, int num_alunos){
	int i;
	FILE *f = fopen(arquivo,"w");

	if ( f == NULL ){
		printf("Erro ao abrir o arquivo %s\n", arquivo);
		exit(0);
	}

	for(i=0; i<num_alunos; i++){
		fprintf(f,"%s %.1f\n", vet[i].nome,  (vet[i].n1 + vet[i].n2 + vet[i].n3)/3 );
	}

	fclose(f);
}
/*---------------------------------------------------------*/
int main(){

	char entrada[50], saida[50];
	int num_alunos;

	printf("Digite o nome do arquivo de entrada:\n");
	scanf("%s", entrada);

	ALUNOS *vet = le_dados_alunos(entrada, &num_alunos);

	printf("Digite o nome do arquivo de saida:\n");
	scanf("%s", saida);

	ordena_alunos(vet, num_alunos);
	gera_arquivo_alunos(saida, vet, num_alunos);

	free(vet);
}
/*---------------------------------------------------------*/

