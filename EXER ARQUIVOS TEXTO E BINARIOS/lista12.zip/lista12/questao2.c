#include <stdio.h>
#include <stdlib.h>

/*-------------------------------------------------------------------*/
void le_arquivo_entrada(char arquivo[50], int cont[6]){
	int n;

	FILE *f = fopen(arquivo, "rb");

	if ( f == NULL ){
		printf("Erro ao abrir o arquivo %s\n", arquivo);
		exit(0);
	}

	while ( fread(&n, sizeof(int), 1, f) ){
		cont[n]++;
	}

	fclose(f);
}
/*-------------------------------------------------------------------*/
void gera_arquivo_saida(char arquivo[50], int cont[6]){
	int i, j;
	FILE *f = fopen(arquivo, "w");

	if ( f == NULL ){
		printf("Erro ao abrir o arquivo %s\n", arquivo);
		exit(0);
	}

	for(i=1; i<6; i++){
		for(j=0; j<cont[i]; j++){
			fprintf(f, "*");
		}
		fprintf(f,"\n");
	}

	fclose(f);
}

/*-------------------------------------------------------------------*/
int main(){
	char entrada[50], saida[50];
	int cont[6] = {0, 0, 0, 0, 0, 0};

	printf("Digite o nome do arquivo de entrada:\n");
	scanf("%s", entrada);

	le_arquivo_entrada(entrada, cont);

	printf("Digite o nome do arquivo de entrada:\n");
	scanf("%s", saida);

	gera_arquivo_saida(saida, cont);
}
/*-------------------------------------------------------------------*/
