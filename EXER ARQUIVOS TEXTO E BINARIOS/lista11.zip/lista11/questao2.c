#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/*--------------------------------------------*/
float media(char matricula[10], char arquivo[50]){

	float p1, p2, p3;
	char aluno[10];
	FILE *f = NULL;

	f = fopen(arquivo,"r");

	if ( f == NULL ){
		printf("Erro ao abrir o arquivo %s\n", arquivo);
		exit(0);
	}

	while ( fscanf(f, "%s %f %f %f\n", aluno, &p1, &p2, &p3) == 4 ){
		if ( strcmp(aluno, matricula ) == 0 ){
			return (( p1 + p2 + p3) / 3 );
		}
	}	

	fclose(f);
	return (-1);
}


/*--------------------------------------------*/
void main(){
	char matricula[10];
	char arquivo[50];
	float m;

	printf("Digite o numero da matricula:\n");
	scanf("%s", matricula);

	printf("Digite o nome do arquivo:\n");
	scanf("%s", arquivo);

	m = media(matricula, arquivo);

	printf("Media: %.2f\n", m);

}
/*--------------------------------------------*/




