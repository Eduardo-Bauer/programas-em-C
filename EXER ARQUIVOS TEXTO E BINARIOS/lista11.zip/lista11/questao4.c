#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*---------------------------------------------------------------------------------------------*/
struct itens{
    char descricao[50];
    float valor;
};
typedef struct itens ITENS;

/*---------------------------------------------------------------------------------------------*/
int main(){
    char descricao[50];
    char entrada[50], saida[50];
    FILE *fin, *fout;
    ITENS *v = NULL;
    int qtd, m, p;    
    int i, j, k;
    float soma;

    printf("Digite o nome do arquivo de entrada:\n");
    scanf("%s", entrada);

    fin = fopen(entrada, "r");

    if (fin == NULL){
        printf("Erro ao abrir o arquivo %s\n", entrada);
        exit(0);
    }
    
    fscanf(fin, "%d", &m);
    
    v = (ITENS *)malloc(m*sizeof(ITENS));    
    
    for(j=0; j<m; j++){
        fscanf(fin, "%s %f", v[j].descricao, &v[j].valor);
    }

    fscanf(fin, "%d", &p);
    soma = 0;
    for(j=0;j<p; j++){
        fscanf(fin, "%s %d", descricao, &qtd);
        for(k=0; k<m; k++){
           if (strcmp(descricao, v[k].descricao)==0){
                        soma+= qtd * v[k].valor;
           }
        }
    }

    printf("Digite o nome do arquivo de saida:\n");
    scanf("%s", saida);

    fout = fopen(saida, "w");
    if ( fout == NULL ){
        printf("Erro ao abrir o arquivo de saida %s\n", saida);
        exit(0);
    } 

    fprintf(fout, "R$ %.2f\n", soma);

    free(v);
    fclose(fin);
    fclose(fout);
}

