#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main(){
    FILE *f = NULL;
    char arquivo[50], linha[100];
    int i, j, cont;
    char holmes[10] = "HOLMES";

    printf("Digite o nome do arquivo de entrada:\n");
    scanf("%s", arquivo);
	
    f = fopen(arquivo,"r");

    if (f == NULL){
	printf("Erro ao abrir o arquivo anterior\n");
	exit(0);
    }
    
    cont = 0;
    while ( fgets(linha, 100, f ) ){
        for (i=0; linha[i]!='\0'; i++){
            if ( toupper(linha[i]) == 'H'){
                j=0;                
                while ( toupper(linha[i+j])== holmes[j] && holmes[j]!='\0' && linha[i+j]!='\0'){
                    j++;
                }
                if (holmes[j]=='\0'){
                    cont++;
                }    
            }
        } 
    }
    
    printf("Numero de vezes: %d\n", cont);
    fclose(f);
}

