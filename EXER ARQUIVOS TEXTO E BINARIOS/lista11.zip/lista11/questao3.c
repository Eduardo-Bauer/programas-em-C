#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*---------------------------------------------------------------------------------------------*/
struct funcionario{
       char cpf[30];
       char nome[50];
       char departamento[30];
       float salario;
};
typedef struct funcionario FUNCIONARIO;

/*---------------------------------------------------------------------------------------------*/
FUNCIONARIO * leArquivo(char *nomeArq, int *totalFunc){
     
     FILE *arq = NULL;
     FUNCIONARIO *func;	
     int i;     

     arq = fopen(nomeArq,"r");
     
     if (arq==NULL){      
             printf("Erro na abertura do arquivo de entrada\n");
             exit(0);
     }   

     fscanf(arq,"%d\n",totalFunc);
     
     printf("TOTAL %d\n",*totalFunc);
     func =(FUNCIONARIO *)malloc(sizeof(FUNCIONARIO)*(*totalFunc));

     for( i=0; i<*totalFunc; i++){
         fgets(func[i].cpf,30,arq);
	 func[i].cpf[strlen(func[i].cpf)-1]='\0';
         fgets(func[i].nome,50,arq);
	 func[i].nome[strlen(func[i].nome)-1]='\0';
         fscanf(arq, "%f\n",&func[i].salario);
         fgets(func[i].departamento,30,arq);
	 func[i].departamento[strlen(func[i].departamento)-1]='\0';
      }

      fclose(arq);
      return(func);
}

/*---------------------------------------------------------------------------------------------*/
void escreveArquivo(FUNCIONARIO *func,char *nomeArq, int totalFunc){
     FILE *arq = NULL;
     int i;

     arq = fopen(nomeArq,"w");
     if (arq==NULL){      
             printf("Erro na abertura do arquivo de saida\n");
             exit(0);
     }        

     fprintf(arq,"%d\n",totalFunc);
     for( i=0; i<totalFunc; i++){
	  fprintf(arq, "%s %s %.2f %s\n", func[i].cpf, func[i].nome, func[i].salario, func[i].departamento);
     }
     fclose(arq);
}

/*---------------------------------------------------------------------------------------------*/
void ordenaFuncionarios(FUNCIONARIO *func, int totalFunc){
     FUNCIONARIO aux;
     int i,j;
     
     for(i=0;i<totalFunc;i++){
         for(j=0;j<totalFunc-1;j++){
             if ( strcmp(func[j].nome,func[j+1].nome) > 0) {
                 aux = func[j];
                 func[j] = func[j+1];
                 func[j+1] = aux;
             }     
         }
     }                                 
}     

/*---------------------------------------------------------------------------------------------*/
void escreveFuncionarios(FUNCIONARIO *func, int totalFunc){
     int i;
     fprintf(stdout,"---------------------------------------\n");
     for(i=0;i<totalFunc;i++){
        fprintf(stdout,"Nome: %s",func[i].nome);
        fprintf(stdout,"CPF: %s",func[i].cpf);
        fprintf(stdout,"Departamento: %s",func[i].departamento);
        fprintf(stdout,"Departamento: %f\n",func[i].salario);
        fprintf(stdout,"---------------------------------------\n");
     }   
}

/*---------------------------------------------------------------------------------------------*/
int main(int argc, char **argv){

	FUNCIONARIO *func = NULL;
	int totalFunc;
	char entrada[50], saida[50];

	printf("Digite o nome do arquivo de entrada:\n");
	scanf("%s", entrada);

	printf("Digite o nome do arquivo de saida:\n");
	scanf("%s", saida);

        func = leArquivo(entrada, &totalFunc);

        ordenaFuncionarios(func, totalFunc);

        escreveArquivo(func, saida, totalFunc);

    	free(func);
}
/*---------------------------------------------------------------------------------------------*/

