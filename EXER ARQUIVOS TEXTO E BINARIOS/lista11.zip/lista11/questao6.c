#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*--------------------------------------------------------------*/
struct medalhas{
	char nome[50];
	int o, p, b;
};
typedef struct medalhas MEDALHAS;

/*--------------------------------------------------------------*/
MEDALHAS * le_dados_medalhas(char arquivo[50], int *num_paises){ 
    int i, np;
    FILE *f = fopen(arquivo, "r");

    if ( f == NULL ){
        printf("Erro ao abrir o arquivo %s\n", arquivo);
        exit(0);
    }
     
    fscanf(f, "%d\n", &np);

    MEDALHAS *m = (MEDALHAS *)malloc( np * sizeof(MEDALHAS));

    for(i=0; i<np; i++){
	fscanf(f, "%s %d %d %d\n", m[i].nome, &m[i].o, &m[i].p, &m[i].b);
    }	

    fclose(f);
    
    *num_paises = np;
    return m;	
}
/*--------------------------------------------------------------*/
void ordena_medalhas(MEDALHAS *m, int num_paises){
    int i, j;
    MEDALHAS aux;	
    for(i=0; i<num_paises-1; i++){
       for(j=0; j<num_paises-1-i; j++){
	  if ( ( m[j].o < m[j+1].o)  || 
               ( m[j].o == m[j+1].o && m[j].p < m[j+1].p) ||
               ( m[j].o == m[j+1].o && m[j].p == m[j+1].p && m[j].b < m[j+1].b ) ||
 	       ( m[j].o == m[j+1].o && m[j].p == m[j+1].p && m[j].b == m[j+1].b && strcasecmp(m[j].nome, m[j+1].nome)>0)){
		aux = m[j];
		m[j] = m[j+1];
		m[j+1] = aux;
	  }	
       }
    }
}
/*--------------------------------------------------------------*/
void escreve_dados_medalhas(char arquivo[50], MEDALHAS *m, int num_paises){
    int i;
    FILE *f = fopen(arquivo, "w");

    if ( f == NULL ){
        printf("Erro ao abrir o arquivo %s\n", arquivo);
        exit(0);
    }	

    for(i=0; i<num_paises; i++){
	fprintf(f, "%s %d %d %d\n", m[i].nome, m[i].o, m[i].p, m[i].b);
    }	

    fclose(f);
}
/*--------------------------------------------------------------*/
int main(){
	char entrada[50], saida[50];
	int num_paises;

	printf("Digite o nome do arquivo de entrada:\n");
	scanf("%s", entrada);

	MEDALHAS *m = le_dados_medalhas(entrada, &num_paises);

	ordena_medalhas(m, num_paises);

	printf("Digite o nome do arquivo de saida:\n");
	scanf("%s", saida);

	escreve_dados_medalhas(saida, m, num_paises);

	free(m);
}
/*--------------------------------------------------------------*/



