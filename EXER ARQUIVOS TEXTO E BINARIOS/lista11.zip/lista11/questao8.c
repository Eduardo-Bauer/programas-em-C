#include <stdio.h>
#include <stdlib.h>

/*---------------------------------------------------------------------------*/
void merge_arquivo(char arquivo1[50], char arquivo2[50], char final[50]){
  
    int n1, n2, r1, r2;
    
    FILE *f1 = fopen(arquivo1, "r");

    if ( f1 == NULL ){
        printf("Erro ao abrir o arquivo %s\n", arquivo1);
        exit(0);
    }

    FILE *f2 = fopen(arquivo2, "r");

    if ( f2 == NULL ){
        printf("Erro ao abrir o arquivo %s\n", arquivo2);
        exit(0);
    }

    FILE *fo = fopen(final, "w");

    if ( fo == NULL ){
        printf("Erro ao abrir o arquivo %s\n", final);
        exit(0);
    }

    r1 = fscanf(f1, "%d", &n1);
    r2 = fscanf(f2, "%d", &n2);

    while ( r1==1 && r2==1 ){
            if ( n1 < n2 ){
                fprintf(fo, "%d\n", n1);
                r1 = fscanf(f1, "%d", &n1);
            }
            else{
                fprintf(fo, "%d\n", n2);
                r2 = fscanf(f2, "%d", &n2);
            }
    }

    while ( r1 == 1 ){
        fprintf(fo, "%d\n", n1);
        r1 = fscanf(f1, "%d", &n1);
    }

    while ( r2 == 1 ){
        fprintf(fo, "%d\n", n2);
        r2 = fscanf(f2, "%d", &n2);
    }
 
    fclose(f1);
    fclose(f2);
    fclose(fo);
}

/*---------------------------------------------------------------------------*/
int main(){
    char arquivo1[50], arquivo2[50], final[50];

    printf("Digite o nome do primeiro arquivo:\n");
    scanf("%s", arquivo1);

    printf("Digite o nome do segundo arquivo:\n");
    scanf("%s", arquivo2);

    printf("Digite o nome do arquivo final:\n");
    scanf("%s", final);

    merge_arquivo(arquivo1, arquivo2, final);


}
