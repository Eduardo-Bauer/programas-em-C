#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/*--------------------------------------------*/
void medias(char arquivo[50], int *aprovados, int *reprovados){

	float p1, p2, p3, m;
	char nome[80];

	FILE *f = fopen(arquivo,"r");

	if ( f == NULL ){
		printf("Erro ao abrir o arquivo %s\n", arquivo);
		exit(0);
	}

	*aprovados = 0;
	*reprovados = 0;

	while ( fgets(nome, 80, f) > 0 ) {
		fscanf(f, "%f %f %f\n", &p1, &p2, &p3);
		m = (p1 + p2 + p3 )/3;

		if ( m >= 5 ){
			(*aprovados)++;
		}
		else{
			(*reprovados)++;
		}
	}	
	fclose(f);
}
/*--------------------------------------------*/
void main(){
	char arquivo[50];
	int aprovados, reprovados;
	
	printf("Digite o nome do arquivo:\n");
	scanf("%s", arquivo);

	medias(arquivo, &aprovados, &reprovados);

	printf("Aprovados: %d\n", aprovados);
	printf("Reprovados: %d\n", reprovados);
}
/*--------------------------------------------*/




