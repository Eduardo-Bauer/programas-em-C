#include <stdio.h>
#include <stdlib.h>

/*---------------------------------------------------------------------------------------------*/
int main(){
    FILE *fin, *fout; 
    char entrada[50], saida[50];
    int i, cod, num;
    float soma, val;

    printf("Digite o nome do arquivo de entrada:\n");
    scanf("%s", entrada);

    fin = fopen(entrada, "r");

    if (fin == NULL){
        printf("Erro ao abrir o arquivo %s\n", entrada);
        exit(0);
    }
    
    printf("Digite o nome do arquivo de saida:\n");
    scanf("%s", saida);

    fout = fopen(saida, "w");
    if ( fout == NULL ){
        printf("Erro ao abrir o arquivo de saida %s\n", saida);
        exit(0);
    } 

    while ( fscanf(fin, "%d %d", &cod, &num) == 2 ){
 	   soma = 0;
	   for(i=0; i<num; i++){
		fscanf(fin, "%f", &val);
                soma += val;
	   } 
	   fprintf(fout, "% 5d % 3d % 5.1f\n", cod, num, soma/num);
    }	

 
    fclose(fin);
    fclose(fout);
}

