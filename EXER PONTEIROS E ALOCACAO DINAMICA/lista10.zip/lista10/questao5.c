#include <stdio.h>
#include <stdlib.h>

/*-------------------------------------------------------*/
int * primos(int n){

	int *vet = NULL;
	int i, d, p, num = 5;

	vet = (int *)malloc(n*sizeof(int));
	i = 0;
	while  ( i < n ){
		if ( i < 2 ){
			vet[i] = i + 2;
			i++;		
		}
		else{
			p = 1;
			for(d=0; d<i-1 && p==1;d++){
				if (num % vet[d] == 0){
					p = 0;
				} 
			}
			if ( p ){
				vet[i++] = num;
			}
			num +=2;
		}
	}	
	return vet;
}

/*-------------------------------------------------------*/
int main(){
	int *vet = NULL;
	int i, n;

	printf("Digite o tamanho do vetor:\n");
	scanf("%d", &n);

	vet = primos(n);

	for(i=0; i<n; i++){
		printf("%d\n", vet[i]);
	}

	free(vet);
}
/*-------------------------------------------------------*/



