#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/*-------------------------------------------*/
char * gera_string(int n){
	char *str = NULL;
	int i, tipo;

	str = (char *)malloc((n+1)*sizeof(char));

	srand(time(NULL));

	for(i=0; i<n; i++){
		tipo = rand() % 3;
		switch(tipo){
			case 0: str[i] = '0' + rand() % 10;
				break;
			case 1: str[i] = 'A' + rand() % 26;
				break;
			case 2: str[i] = 'a' + rand() % 26;
				break;
		}
	}
	str[i] = '\0';

	return str;

}

/*-------------------------------------------*/
int main(){
	int n;
	char c, *str = NULL;
	
	printf("Digite o numero de caracteres:\n");	
	scanf("%d", &n);

	str = gera_string(n);

	printf("Gerada: %s\n", str);

	free(str);

}
/*-------------------------------------------*/
