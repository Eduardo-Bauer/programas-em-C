#include <stdio.h>
#include <stdlib.h>

/*-------------------------------------------------------*/
int * fibonacci(int n){

	int *vet = NULL;
	int i;

	vet = (int *)malloc(n*sizeof(int));
	
	for(i=0; i<n; i++){
		if ( i < 2 ){
			vet[i] = i;
		}
		else{
			vet[i] = vet[i-1] + vet[i-2];
		}
	}
	return vet;
}

/*-------------------------------------------------------*/
int main(){
	int *vet = NULL;
	int i, n;

	printf("Digite o tamanho do vetor:\n");
	scanf("%d", &n);

	vet = fibonacci(n);

	for(i=0; i<n; i++){
		printf("%d\n", vet[i]);
	}

	free(vet);
}
/*-------------------------------------------------------*/



