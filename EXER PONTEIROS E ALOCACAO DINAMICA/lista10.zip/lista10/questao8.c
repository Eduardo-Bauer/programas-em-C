#include <stdio.h>
#include <stdlib.h>

/*---------------------------------------------------------------*/
#define N 5

/*---------------------------------------------------------------*/
struct naonulo{
  int valor; 
  int linha; 
  int coluna;
};
typedef struct naonulo NAONULO;

/*---------------------------------------------------------------*/
NAONULO * naonulos(int M[N][N], int *num_nao_nulos){
	int nnulos = 0;
	int i, j, k;

	NAONULO *vet = NULL;

	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			if ( M[i][j]!= 0){
				nnulos++;
			}
		}
	}

	vet = (NAONULO *)malloc(nnulos*sizeof(NAONULO));

	k = 0;
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			if ( M[i][j]!= 0){
				vet[k].valor = M[i][j];
				vet[k].linha = i;
				vet[k].coluna = j;
				k++;
			}
		}
	}

	*num_nao_nulos = nnulos; 
	return vet;
}
/*---------------------------------------------------------------*/
void le_matriz(int M[N][N]){
	int i,j;
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			printf("Digite o valor:\n");
			scanf("%d", &M[i][j]);	
		}
	}
}
/*---------------------------------------------------------------*/
void escreve_matriz(int M[N][N]){
	int i,j;
	for(i=0; i<N; i++){
		for(j=0; j<N; j++){
			printf("% 5d", M[i][j]);	
		}
		printf("\n");
	}
}
/*---------------------------------------------------------------*/
void escreve_naonulos(NAONULO *vet, int num_nao_nulos){
	int i;
	for(i=0; i<num_nao_nulos; i++){
		printf("Valor: %d	Linha: %d	Coluna: %d\n", vet[i].valor, vet[i].linha, vet[i].coluna);	
	}


}
/*---------------------------------------------------------------*/
int main(){
	int M[N][N];	
	NAONULO * vet = NULL;
	int num_nao_nulos;

	le_matriz(M);
	escreve_matriz(M);

	vet = naonulos(M, &num_nao_nulos);
	escreve_naonulos(vet, num_nao_nulos);

	free(vet);

}
