#include <stdlib.h>
#include <stdio.h>

/*---------------------------------------------------------------*/
struct data {
	int dia;
	int mes;
	int ano;
};
typedef struct data DATA;


struct cliente {
	int codigo;
	char nome[50];
	DATA nasc;
};
typedef struct cliente CLIENTE;


/*---------------------------------------------------------------*/
CLIENTE* maior_de_idade(CLIENTE *vet, int num_clientes, int dia_atual, int mes_atual, int ano_atual, int *num_maiores_idade){

	CLIENTE *maiores = NULL;
	int i, j;
	
	*num_maiores_idade = 0;
	for(i=0; i<num_clientes; i++){
	   if ( (ano_atual-vet[i].nasc.ano>18) ||
	        (ano_atual-vet[i].nasc.ano==18 && mes_atual>vet[i].nasc.mes) ||
		(ano_atual-vet[i].nasc.ano==18 && mes_atual==vet[i].nasc.mes && dia_atual>=vet[i].nasc.dia) ){
		(*num_maiores_idade)++;
	   }	
	}

	if ( *num_maiores_idade == 0 ){
		return NULL;
	}
	else{
		maiores = (CLIENTE *)malloc(*num_maiores_idade * sizeof(CLIENTE));
		j = 0;
		for(i=0; i<num_clientes; i++){
		     if ( (ano_atual-vet[i].nasc.ano>18) ||
		        (ano_atual-vet[i].nasc.ano==18 && mes_atual>vet[i].nasc.mes) ||
			(ano_atual-vet[i].nasc.ano==18 && mes_atual==vet[i].nasc.mes && dia_atual>=vet[i].nasc.dia) ){
			maiores[j++] = vet[i]; 
		     }
		}
		return maiores;
	}
}
/*---------------------------------------------------------------*/
void le_clientes(CLIENTE *vet, int num_clientes){
	int i;
	for(i=0; i<num_clientes; i++){
		printf("Cliente %d\n", i);
		vet[i].codigo = i;
		getchar();
		printf("Digite o nome:\n");
		gets(vet[i].nome);
		printf("Digite a data de nascimento:\n");
		scanf("%d/%d/%d", &vet[i].nasc.dia, &vet[i].nasc.mes, &vet[i].nasc.ano);
	}	
}
/*---------------------------------------------------------------*/
void escreve_clientes(CLIENTE *vet, int num_clientes){
	int i;
	for(i=0; i<num_clientes; i++){
		printf("Codigo: %d \t Nome: %s \t Data de Nascimento: %d/%d/%d\n", vet[i].codigo, vet[i].nome,
			vet[i].nasc.dia, vet[i].nasc.mes, vet[i].nasc.ano);
	}	
}
/*---------------------------------------------------------------*/

void main(){

	int num_clientes, num_maiores_idade;
	int dia_atual, mes_atual, ano_atual;

	printf("Digite o numero de clientes:\n");
	scanf("%d", &num_clientes);

	CLIENTE *vet = (CLIENTE *)malloc(num_clientes*sizeof(CLIENTE));

	le_clientes(vet, num_clientes);
	escreve_clientes(vet, num_clientes);
	
	printf("Digite a data atual:\n");
	scanf("%d/%d/%d", &dia_atual, &mes_atual, &ano_atual);

	CLIENTE *maiores = maior_de_idade(vet, num_clientes, dia_atual, mes_atual, ano_atual, &num_maiores_idade);
	escreve_clientes(maiores, num_maiores_idade);
	
	free(vet);
	free(maiores);
}
