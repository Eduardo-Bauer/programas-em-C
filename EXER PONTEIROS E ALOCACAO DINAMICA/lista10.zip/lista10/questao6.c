#include <stdio.h>
#include <stdlib.h>

/*---------------------------------------------------------------*/
#define N1 5
#define N2 5

/*---------------------------------------------------------------*/
int*  interseccao(int *x1, int *x2, int n1, int n2, int* qtd){
	int flag, k, i, j;
	int *x3;

	*qtd=0;

	for(i=0; i<n1; i++){
		flag = 0;
		for(j=0; j<n2 && !flag; j++){
			if ( x1[i] == x2[j]){
				flag = 1;
			}
		}
		if (flag){
			(*qtd)++;
		}
	}

	x3 = (int *)malloc((*qtd)*sizeof(int));
	
	k = 0;
	for(i=0; i<n1; i++){
		flag = 0;
		for(j=0; j<n2 && !flag; j++){
			if ( x1[i] == x2[j]){
				flag = 1;
				x3[k++] = x1[i];
			}
		}
	}

	return x3;
}

/*---------------------------------------------------------------*/
void escreve(int *vet, int n){
	int i;
	for(i=0; i<n; i++){
		printf("%d\n", vet[i]);
	}
}

/*---------------------------------------------------------------*/
int main(){

	int x1[N1] = {1,3,5,6,7};
	int x2[N2] = {1,3,4,6,8};
	int *x3;
	int qtd;

	x3 =  interseccao(x1, x2, N1, N2, &qtd);

	escreve(x3, qtd);	

	free(x3);
}
/*---------------------------------------------------------------*/

