#include <stdio.h>
#include <stdlib.h>

/*---------------------------------------------------------------*/
#define N1 5
#define N2 5

/*---------------------------------------------------------------*/
int* uniao(int *x1, int *x2, int n1, int n2, int* qtd){
	int flag, k, i, j;
	int *x3;

	*qtd=5;

	for(i=0; i<n2; i++){
		flag = 0;
		for(j=0; j<n1 && !flag; j++){
			if ( x2[i] == x1[j]){
				flag = 1;
			}
		}
		if (!flag){
			(*qtd)++;
		}
	}

	x3 = (int *)malloc((*qtd)*sizeof(int));
	
	for(k=0; k<n1; k++){
		x3[k] = x1[k];
	}

	
	for(i=0; i<n2; i++){
		flag = 0;
		for(j=0; j<n1 && !flag; j++){
			if ( x2[i] == x1[j]){
				flag = 1;
			}
		}
		if (!flag){
			x3[k++] = x2[i];
		}
	}

	return x3;
}

/*---------------------------------------------------------------*/
int escreve(int *vet, int n){
	int i;
	for(i=0; i<n; i++){
		printf("%d\n", vet[i]);
	}
}
/*---------------------------------------------------------------*/
int main(){

	int x1[N1] = {1,3,5,6,7};
	int x2[N2] = {1,3,4,6,8};
	int *x3;
	int qtd;

	x3 = uniao(x1, x2, N1, N2, &qtd);

	escreve(x3, qtd);	

	free(x3);
}
/*---------------------------------------------------------------*/

