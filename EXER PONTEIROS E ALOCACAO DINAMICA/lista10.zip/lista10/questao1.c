#include <stdio.h>
#include <stdlib.h>

/*-------------------------------------------*/
char * gera_string(char c, int n){
	char *str = NULL;
	int i;

	str = (char *)malloc((n+1)*sizeof(char));

	for(i=0; i<n; i++){
		str[i] = c;
	}
	str[i] = '\0';

	return str;

}

/*-------------------------------------------*/
int main(){
	int n;
	char c, *str = NULL;
	
	printf("Digite o caracter:\n");	
	scanf("%c", &c);

	printf("Digite o numero de vezes:\n");	
	scanf("%d", &n);

	str = gera_string(c, n);

	printf("Gerada: %s\n", str);

	free(str);

}
/*-------------------------------------------*/
