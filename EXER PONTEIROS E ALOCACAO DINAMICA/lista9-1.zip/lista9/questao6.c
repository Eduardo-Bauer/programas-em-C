#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/*---------------------------------------------------------------*/
int eh_primo(int n){
	int i;

	if (n<=1){
		return 0;
	}
	for(i=2; i<=n/2; i++){
		if ( n % i == 0){
			return 0;
		}
	}
	return 1;
}

/*---------------------------------------------------------------*/
void menor_primo(int M[15][15], int *primo, int *lin, int *col){
	int i, j;

	*primo = -1;
	*lin = -1;
	*col = -1;

	for(i=0; i<15; i++){
	    for(j=0; j<15; j++){
		if ( eh_primo(M[i][j]) && (M[i][j]<*primo || *primo==-1)){
			*primo = M[i][j];
			*lin = i;
			*col = j;
		}
	    }
	}
}
/*---------------------------------------------------------------*/
void gera_matriz(int M[15][15]){
	int i, j;
	srand(time(NULL));
	for(i=0; i<15; i++){
	    for(j=0; j<15; j++){
		M[i][j] = rand() % 100;
	    }
	}
}
/*---------------------------------------------------------------*/
void escreve_matriz(int M[15][15]){
	int i, j;
	for(i=0; i<15; i++){
	    for(j=0; j<15; j++){
		printf("% 5d", M[i][j]);
	    }
	    printf("\n");
	}
}
/*---------------------------------------------------------------*/
int main(){
	int M[15][15];
	int p, l, c;

	gera_matriz(M);
	escreve_matriz(M);

	menor_primo(M, &p, &l, &c);

	printf("Primo: %d  Linha: %d Coluna: %d\n", p, l, c);

}
/*---------------------------------------------------------------*/
