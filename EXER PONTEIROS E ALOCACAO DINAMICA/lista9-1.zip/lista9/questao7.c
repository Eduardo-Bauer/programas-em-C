#include <stdio.h>
#include <string.h>

/*----------------------------------------------------------------*/
void dois_maiores(char str[], int *primeiro, int *segundo){
    int i, num =0;
    *primeiro = 0;
    *segundo = 0;

    for(i=0; i<=strlen(str); i++){
        if ( str[i]>='0' && str[i]<='9'){
            num = num*10 + (str[i]-'0');
        }
        else{
            if ( num > *primeiro ){
                *segundo = *primeiro;
                *primeiro = num;
            }
            else if ( num > *segundo){
                *segundo = num;                
            }
            num = 0;
        }
    }
}
/*----------------------------------------------------------------*/
int main(){
    char str[100];
    int p, s;

    printf("Digite a string:\n");
    scanf("%s", str);

    dois_maiores(str, &p, &s);

    printf("Primeiro: %d Segundo: %d\n", p, s);

}

/*----------------------------------------------------------------*/


