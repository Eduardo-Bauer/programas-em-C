#include <stdio.h>

/*-------------------------------------------*/
void verificadores(int cpf, int *d1, int *d2){
	int soma1 = 0 , soma2 = 0;
	int mult1 = 2, mult2 = 3;
	int d, resto; 

	while ( cpf > 0 ){
		d = cpf % 10;
		cpf /= 10;
		soma1 += mult1 * d;
		soma2 += mult2 * d;
		mult1++;
		mult2++;
	}

	resto = soma1 % 11;
	if (  resto == 0  ||  resto == 1 ){
		*d1 = 0;
	}
	else{
		*d1 = 11 - resto;
	}

	soma2 += *d1 * 2;

	resto = soma2 % 11;
	if (  resto == 0  ||  resto == 1 ){
		*d2 = 0;
	}
	else{
		*d2 = 11 - resto;
	}

}

/*-------------------------------------------*/
int main(){
	int cpf, d1, d2;

	printf("Digite os 9 primeiros valores do cpf:\n");
	scanf("%d", &cpf);

	verificadores(cpf, &d1, &d2);

	printf("D1= %d e D2= %d\n", d1, d2);
}
/*-------------------------------------------*/
