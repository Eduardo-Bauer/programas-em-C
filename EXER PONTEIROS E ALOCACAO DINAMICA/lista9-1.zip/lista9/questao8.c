#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N 6

/*---------------------------------------------------------*/
struct alunos{
    char nome[50];
    float n1, n2, n3;
    float media;
};
typedef struct alunos ALUNOS;

/*---------------------------------------------------------*/
void le_alunos(ALUNOS vet[N]){
    int i;
    for(i=0; i<N; i++){
        printf("Digite o nome do aluno:\n");
        gets(vet[i].nome);
        printf("Digite as 3 notas do aluno:\n");
        scanf("%f %f %f", &vet[i].n1, &vet[i].n2, &vet[i].n3);
        vet[i].media = (vet[i].n1 + vet[i].n2 + vet[i].n3)/3;         
        getchar();    
    }
}
/*---------------------------------------------------------*/
void escreve_alunos(ALUNOS vet[N]){
    int i;
  	for(i=0; i<N; i++){
		printf("%s %.1f\n", vet[i].nome,  vet[i].media);
	}
}

/*---------------------------------------------------------*/
void menor_maior_medias(ALUNOS vet[N], ALUNOS *menor, ALUNOS *maior){
    int i;
    *menor = vet[0];
    *maior = vet[0];
    for(i=1; i<N; i++){
        if ( menor->media > vet[i].media){
            *menor = vet[i]; 
        }
        if ( maior->media < vet[i].media){
            *maior = vet[i]; 
        }
    }    
}

/*---------------------------------------------------------*/
int main(){
    ALUNOS vet[N], aux;
    ALUNOS menor, maior;

    le_alunos(vet);
    escreve_alunos(vet);
    menor_maior_medias(vet, &menor, &maior);

    printf("Maior Media:\nNome: %s Media: %.1f\n", maior.nome, maior.media);
    printf("Menor Media:\nNome: %s Media: %.1f\n", menor.nome, menor.media);

}
/*---------------------------------------------------------*/

