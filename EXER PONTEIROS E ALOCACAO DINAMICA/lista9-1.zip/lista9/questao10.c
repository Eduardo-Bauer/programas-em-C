#include<stdio.h>
#include<stdlib.h>
#include<string.h>


/*---------------------------------------------------------------*/
#define N 5

/*---------------------------------------------------------------*/
struct candidato{
	char nome[50];
	int pontuacao;
};
typedef struct candidato CANDIDATO;


/*---------------------------------------------------------------*/
void leCandidatos(CANDIDATO c[N]){
	int i;
	for(i=0;i<N;i++){
	    printf("Candidato %i:\n",i);
  	    printf("Digite o nome:\n");
	    gets(c[i].nome);
	    printf("Digite a pontuacao:\n");
	    scanf("%d",&c[i].pontuacao); 	
        getchar();
    }
}


/*---------------------------------------------------------------*/
void maiores_pontuadores(CANDIDATO c[N], CANDIDATO *c1, CANDIDATO *c2){
	int i;
	c1->pontuacao = 0;
	c2->pontuacao = 0;

	for(i=0;i<N;i++){
		if (c[i].pontuacao >= c1->pontuacao){
			c2->pontuacao = c1->pontuacao;
			strcpy(c2->nome, c1->nome);
			c1->pontuacao = c[i].pontuacao;
			strcpy(c1->nome, c[i].nome);		
		}
		else if ( c[i].pontuacao > c2->pontuacao){
			c2->pontuacao = c[i].pontuacao;
			strcpy(c2->nome, c[i].nome);		
		}
	}
}

/*---------------------------------------------------------------*/
int main(){
	CANDIDATO c[N];
	int ncandidatos;
	CANDIDATO c1, c2;

	leCandidatos(c);

	maiores_pontuadores(c, &c1, &c2);

	printf("Candidato %s  Pontuacao: %d\n", c1.nome, c1.pontuacao);
	printf("Candidato %s  Pontuacao: %d\n", c2.nome, c2.pontuacao);
	
}

/*---------------------------------------------------------------*/

