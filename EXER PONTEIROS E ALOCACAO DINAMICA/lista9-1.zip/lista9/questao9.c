#include<stdio.h>
#include <stdlib.h>
#include<math.h>


/*---------------------------------------------------------------*/
#define N 5


/*---------------------------------------------------------------*/
struct ponto{
	float x;
	float y;
};

typedef struct ponto PONTO;


/*---------------------------------------------------------------*/
float distancia(PONTO p1, PONTO p2){
	return( sqrt((p2.x - p1.x)*(p2.x - p1.x)+ (p2.y - p1.y)*(p2.y - p1.y)));
}


/*---------------------------------------------------------------*/
void lePontos(PONTO v[N]){
	int i;
	for(i=0;i<N;i++){
	    printf("Ponto %i: ",i);
	    scanf("%f %f",&v[i].x,&v[i].y); 	
	}
}


/*---------------------------------------------------------------*/
void maior_distancia(PONTO v[N], PONTO *p1, PONTO *p2){
	int i,j;
	float dist, maior =0;

	for(i=0;i<N;i++){
	   for(j=i+1;j<N;j++){
		dist = distancia(v[i],v[j]);
		if (dist > maior){
			maior = dist;
			p1->x = v[i].x;
			p1->y = v[i].y;
			p2->x = v[j].x;
			p2->y = v[j].y;
		}
   	   }	
	}
	
}


/*---------------------------------------------------------------*/
int main(){
	PONTO v[N];
	int npontos;
	PONTO p1, p2;
	
	lePontos(v);

	maior_distancia(v, &p1, &p2);

	printf("Pontos com maior distancia: (%.2f,%.2f) e (%.2f,%.2f)\n", p1.x, p1.y, p2.x, p2.y);
}

/*---------------------------------------------------------------*/

