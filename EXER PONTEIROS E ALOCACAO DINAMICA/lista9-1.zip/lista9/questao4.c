#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/*-------------------------------------------*/
void gera_matriz(int M[5][5]){
	int i, j;
	srand(time(NULL));
	for(i=0; i<5; i++){
		for(j=0; j<5; j++){
			M[i][j] = rand() % 100;
		}
	}
}

/*-------------------------------------------*/
void escreve_matriz(int M[5][5]){
	int i, j;
	for(i=0; i<5; i++){
		for(j=0; j<5; j++){
			printf("% 5d", M[i][j]);
		}
		printf("\n");
	}
}


/*-------------------------------------------*/

void calcula_maior(int M[5][5], int *m, int *l, int *c){
	int i, j;

	*m = M[0][0];
	*l = 0;
	*c = 0;

	for(i=0; i<5; i++){
		for(j=0; j<5; j++){
			if ( M[i][j] > *m ){
				*m = M[i][j];
				*l = i;
				*c = j;
			}
		}
	}
}

/*-------------------------------------------*/
int main(){
	int M[5][5];
	int m, l, c;

	gera_matriz(M);
	escreve_matriz(M);
	calcula_maior(M, &m, &l, &c);

	printf("Maior: %d Posicao: %d %d\n", m, l, c);
}
/*-------------------------------------------*/
