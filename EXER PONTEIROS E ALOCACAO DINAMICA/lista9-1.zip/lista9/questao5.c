#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/*-------------------------------------------*/
void gera_matriz(int M[5][5]){
	int i, j;
	srand(time(NULL));
	for(i=0; i<5; i++){
		for(j=0; j<5; j++){
			M[i][j] = rand() % 100;
		}
	}
}

/*-------------------------------------------*/
void escreve_matriz(int M[5][5]){
	int i, j;
	for(i=0; i<5; i++){
		for(j=0; j<5; j++){
			printf("% 5d", M[i][j]);
		}
		printf("\n");
	}
}


/*-------------------------------------------*/

void calcula_minimax(int M[5][5], int *minimax, int *l, int *c){
	int i, j;
	
	int maior = M[0][0];
	int lin = 0, col =0;
	
	for(i=0; i<5; i++){
		for(j=0; j<5; j++){
			if ( M[i][j] > maior ){
				maior = M[i][j];
				lin = i;
				col = j;
			}
		}
	}

	*minimax = M[lin][0];
	*l = lin;
	*c = 0;
	for(j=1; j<5; j++){
		if ( M[lin][j] < *minimax){
			*minimax = M[lin][j];
			*c = j;
		}	
	}
}

/*-------------------------------------------*/
int main(){
	int M[5][5];
	int minimax, l, c;

	gera_matriz(M);
	escreve_matriz(M);
	calcula_minimax(M, &minimax, &l, &c);

	printf("Minimax: %d Posicao: %d %d\n", minimax, l, c);
}
/*-------------------------------------------*/
