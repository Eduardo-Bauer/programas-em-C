#include <stdio.h>

/*-------------------------------------------*/
void incrementa_hora(int h1, int m1, int min, int *h2, int *m2 ){

	min = (h1 * 60 + m1 + min) % 1440;
	*h2 = min / 60;
	*m2 = min % 60;
}

/*-------------------------------------------*/
int main(){
	int h1, m1, min;
	int h2, m2;

	printf("Digite a hora inicial:\n");
	scanf("%d %d", &h1, &m1);


	printf("Digite o total de minutos:\n");
	scanf("%d", &min);

	incrementa_hora(h1, m1, min, &h2, &m2);

	printf("Hora: %d:%d\n", h2, m2);
}
/*-------------------------------------------*/
