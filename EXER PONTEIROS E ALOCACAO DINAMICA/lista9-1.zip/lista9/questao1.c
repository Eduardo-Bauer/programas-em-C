#include <stdio.h>

/*-------------------------------------------*/
void troca(int *a, int *b){
	int aux;
	aux = *a;
	*a = *b;
	*b = aux;
}

/*-------------------------------------------*/
int main(){
	int a, b;
	printf("Digite os valores:\n");
	scanf("%d %d", &a, &b);

	troca(&a, &b);

	printf("a= %d e b= %d\n", a, b);
}
/*-------------------------------------------*/
