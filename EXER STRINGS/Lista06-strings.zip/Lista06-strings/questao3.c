#include <stdio.h>

/*--------------------------------------*/
char busca_sobrenome(char nome[100], char sobrenome[100]){
    
    int ult, i, k;

    ult = 0;
    for(i=0; nome[i]!='\0'; i++){
        if (nome[i] == ' '){
            ult = i;
        }        
    }

    for(k=0, i=ult+1; nome[i]!='\0'; i++, k++){
        sobrenome[k] = nome[i];    
    }
    sobrenome[k] = '\0';
}

/*--------------------------------------*/
int main(){
    char nome[100] = "Luis Fernando Tavares";
    char sobrenome[100];

    busca_sobrenome(nome, sobrenome);

    printf("Sobrenome: %s\n", sobrenome);    
}
/*--------------------------------------*/




