#include <stdio.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

/*-----------------------------------------------------------------*/
int hex2int(char str[50]){
	int i, n, e;
    
    e = strlen(str)-1; 
   	n = 0;

	for(i=0, e=strlen(str)-1; str[i]!='\0'; i++, e--){
                
        if ( str[i]>='0' && str[i]<='9' ){		
            n += (str[i]-'0') * pow(16,e);
        }
        else{
            n += (toupper(str[i])-'A' + 10) * pow(16,e);
        }
	}

	return n;		
}

/*-----------------------------------------------------------------*/
void main(){
	int n;
	char numero[50];

	printf("Digite o numero em hexadecimal:\n");
	scanf("%s", numero);

	n = hex2int(numero);

	printf("Numero: %d\n", n);
	
}
/*-----------------------------------------------------------------*/
