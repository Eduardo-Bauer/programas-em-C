#include <stdio.h>

/*--------------------------------------*/
int maior(char str[100]){
    
    int i, m, num;
        
    num = 0;
    m = 0;
    for(i=0; str[i]!='\0'; i++){
        if ( str[i] != '#'){
            num = num*10 + (str[i]-'0');
        }
        else{
            if ( num > m){
                m = num;
            }
            num = 0;
        }            
    }

    if ( num > m){
        m = num;
    }
    return m;

}

/*--------------------------------------*/
int main(){
    char str[100] = "10#20#191#7#34";
    
    printf("Maior: %d\n", maior(str));    
}
/*--------------------------------------*/




