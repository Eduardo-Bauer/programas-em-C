#include <stdio.h>
#include <ctype.h>

/*--------------------------------------*/
int ehvogal(char c){
    if ( toupper(c) == 'A' || toupper(c) == 'E' || toupper(c) == 'I' || toupper(c) == 'O' || toupper(c) == 'U'){
        return 1;
    }
    else{
        return 0;
    }
}

/*--------------------------------------*/
float percentual(char str[100]){
    int i, vogal, total;
    
    vogal = 0;
    total = 0;

    for(i=0; str[i]!='\0'; i++){
        if ( ehvogal(str[i]) ){
            vogal++;
        }
        total++;    
    }

    return (vogal * 100.0)/total;
}
/*--------------------------------------*/
int main(){
    //char str[100] = "programacaodecomputadoresII";
    char str[100];

    printf("Digite a string:\n");
    gets(str);

    printf("Percentual: %.4f%%\n", percentual(str));    

}




