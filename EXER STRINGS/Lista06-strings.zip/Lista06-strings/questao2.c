#include <stdio.h>
#include <ctype.h>

/*--------------------------------------*/
int somaDigitos(char str[100]){
    int i, soma = 0;

    for(i=0; str[i]!='\0'; i++){
        if ( str[i]>='0' && str[i]<='9'){
            soma += str[i] - '0';
        }
    }
    return soma;
}

/*--------------------------------------*/
int main(){
    printf("Soma: %d\n", somaDigitos("abcde"));
    printf("Soma: %d\n", somaDigitos("1234"));
    printf("Soma: %d\n", somaDigitos("a36]8"));
    printf("Soma: %d\n", somaDigitos(""));
}
/*--------------------------------------*/




