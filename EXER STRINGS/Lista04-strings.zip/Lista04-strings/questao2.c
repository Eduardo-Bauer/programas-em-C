#include <stdio.h>

/*-----------------------------------------------------------------*/
void duplica(char str[50], char nova[100]){
	int i, j;

	j= 0;
	for(i=0; str[i]!='\0'; i++){
		nova[j] = str[i];
		j++;
		nova[j] = str[i];
		j++;
	}
	nova[j]='\0';
}

/*-----------------------------------------------------------------*/
void main(){
	char palavra[50], nova[100];

	printf("Digite o string:\n");
	scanf("%s", palavra);

	duplica(palavra, nova);

	printf("Duplicada: %s\n", nova);
}
/*-----------------------------------------------------------------*/
