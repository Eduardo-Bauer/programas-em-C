#include <stdio.h>

/*-----------------------------------------------------------------*/
void gera_string(char str[50], char c, int n){
	int i;

	for(i=0; i<n; i++){
		str[i] = c;

	}	 
	str[i] = '\0';
}

/*-----------------------------------------------------------------*/
void main(){
	char c;
	int n;
	char str[50];

	printf("Digite a letra:\n");
	scanf("%c", &c);

	printf("Digite o numero de vezes:\n");
	scanf("%d", &n);

	gera_string(str,c,n);

	printf("Gerada: %s\n", str);
}
/*-----------------------------------------------------------------*/
