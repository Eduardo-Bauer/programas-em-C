#include <stdio.h>

/*-----------------------------------------------------------------*/
int tamanho(char str[50]){
	int i = 0;
	while ( str[i]!= '\0'){
		i++;
	}
	
	return(i);
}

/*-----------------------------------------------------------------*/
int palindromo(char str[50]){
	int i, f;

	f = tamanho(str) - 1;

	for(i=0; i<f; i++){
		if (str[i] != str[f]){
			return 0;			
		}
		f--;
	}	 
	return 1;
}

/*-----------------------------------------------------------------*/
void main(){
	char palavra[50];

	printf("Digite a palavra:\n");
	scanf("%s", palavra);

	if ( palindromo(palavra) ){
		printf("A palavra %s e palindromo\n", palavra);
	}
	else{
		printf("A palavra %s nao e palindromo\n", palavra);
	}
}
/*-----------------------------------------------------------------*/
