#include <stdio.h>

/*-----------------------------------------------------------------*/
int tamanho(char str[50]){
	int i = 0;
	while ( str[i]!= '\0'){
		i++;
	}
	
	return(i);
}

/*-----------------------------------------------------------------*/
void inverte(char str[50]){
	int i, f;
	char aux;
	f = tamanho(str) -1;

	for (i=0; i<f; i++){
		aux = str[i];
		str[i] = str[f];
		str[f] = aux;
		f--;
	}
}

/*-----------------------------------------------------------------*/
void digitos(char str[50], int n){
	int i, r;
	
	i = 0;
	while ( n > 0 ){
		r = n % 10;
		str[i] = r + '0';
		i++;
		n /= 10; 
	}
	str[i] ='\0';

	inverte(str); 

}

/*-----------------------------------------------------------------*/
void main(){
	int n;
	char numero[50];

	printf("Digite o numero:\n");
	scanf("%d", &n);

	digitos(numero, n);

	printf("Numero convertido para string: %s\n", numero);
	
}
/*-----------------------------------------------------------------*/
