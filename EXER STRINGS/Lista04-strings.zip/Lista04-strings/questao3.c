#include <stdio.h>

/*-----------------------------------------------------------------*/
void espaco(char str[50], char nova[100]){
	int i, j;

	j= 0;
	for(i=0; str[i]!='\0'; i++){
		nova[j] = str[i];
		j++;
		nova[j] = ' ';
		j++;
	}
	nova[j-1]='\0';

}

/*-----------------------------------------------------------------*/
void main(){
	char palavra[50], nova[100];

	printf("Digite o string:\n");
	gets(palavra);

	espaco(palavra, nova);

	printf("Espacos: %s\n", nova);
}
/*-----------------------------------------------------------------*/
