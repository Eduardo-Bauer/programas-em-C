#include <stdio.h>

/*-----------------------------------------------------------------*/
int converte_numero(char str[50]){
	int i, n;

	n = 0;

	for(i=0; str[i]!='\0'; i++){
		n = n*10 + (str[i]-'0');
	}

	return n;		
}

/*-----------------------------------------------------------------*/
void main(){
	int n;
	char numero[50];

	printf("Digite o numero:\n");
	scanf("%s", numero);

	n = converte_numero(numero);

	printf("Numero: %d\n", n);
	
}
/*-----------------------------------------------------------------*/
