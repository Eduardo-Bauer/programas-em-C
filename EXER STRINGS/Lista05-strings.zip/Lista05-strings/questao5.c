#include <stdio.h>
#include <stdio_ext.h>

//---------------------------------------------------
#define N 100

//---------------------------------------------------
int strin(char str1[N],char str2[N]){
	int i, k;

	for(i=0; str2[i]!='\0'; i++){

		if (str1[0] == str2[i]){
			k=0;
			while ( str1[k]!='\0' && str2[i+k]!='\0' && str1[k]==str2[i+k]){
				k++;
			} 
			if ( str1[k] == '\0'){
				return(1);
			}
		}
	}
	return(0);	 
	
	
}
//--------------------------------------------------
int main(){
	int n;	
	char str1[N]="astro", str2[N]="mastro";

	if ( strin(str1, str2) ){
		printf("Esta no string 2\n");
	} 
	else{
	       printf("Nao esta no string 2\n");	
	} 
}
//--------------------------------------------------

