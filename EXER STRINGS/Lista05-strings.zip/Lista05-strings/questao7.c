#include <stdio.h>

/*----------------------------------------------------------------------*/
int main(){
	char passaporte[9], proximo[9];
	char soma = 0;
	int i, vai;

	printf("Digite o passaporte: ");
	scanf("%s", passaporte);

	vai = 1;

	for (i=7; i>=0; i--){
		soma = passaporte[i] + vai;

		if ( i >= 2  && soma > '9'){
			proximo[i] = '0';
			vai = 1;		
		}
		else if ( i < 2 && soma > 'Z' ){
			proximo[i] = 'A';	
			vai = 1;
		}
		else{
			proximo[i] = soma;
			vai = 0;			
		}					
	}
	proximo[8] = '\0';

	printf("%s\n", proximo);

}
/*----------------------------------------------------------------------*/


