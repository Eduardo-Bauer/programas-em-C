#include <stdio.h>
#include <stdio_ext.h>

//---------------------------------------------------
#define N 100

//---------------------------------------------------
void int2bin(int numero, char str[N]){
	int i, j, t, resto;
	char aux;

	i = 0;
	while ( numero > 0 ){
		resto = numero % 2;
		numero /= 2;
		str[i++] = resto + '0';
	}
	str[i] = 0;
	
	t = i;

	for(i=0, j=t-1; i<j; i++, j--){
		aux = str[i];
		str[i] = str[j];
		str[j] = aux;		
	} 	
	
}
//--------------------------------------------------
int main(){
	int n;	
	char str[N];
	
	printf("Digite o valor:\n");
	scanf("%d", &n);

	int2bin(n, str);

	printf("Numero: %s\n", str); 
}
//--------------------------------------------------

