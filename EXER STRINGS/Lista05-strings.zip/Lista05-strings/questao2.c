#include <stdio.h>
#include <stdio_ext.h>

//---------------------------------------------------
#define N 100

//---------------------------------------------------
int chrtimes(char str1[N], char ch){
	int i, cont = 0;
	for(i=0; str1[i]!='\0'; i++){
		if (str1[i] == ch){
			cont++;
		} 
	}
	return cont;
}
//--------------------------------------------------
int main(){
	char str1[N];
	char ch;

	printf("Digite o caracter:\n");
	scanf("%c", &ch);
	
	__fpurge(stdin);

	printf("Digite a string:\n");
	gets(str1);


	printf("Vezes: %d\n", chrtimes(str1, ch)); 
}
//--------------------------------------------------

