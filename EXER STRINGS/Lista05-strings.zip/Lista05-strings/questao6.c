#include <stdio.h>
#include <string.h>
#include <stdio_ext.h>

//---------------------------------------------------
#define N 1000

//---------------------------------------------------
void descompacta(char str1[N], char str2[N]){

	int i, j, k;
	int num;

	k =0;
	for(i=0; str1[i]!='\0'; ){
		if ( str1[i] == '#'){
			i++;
			num = 0;
			while ( str1[i] >='0' && str1[i]<='9'){
				num = num * 10 + (str1[i]-'0'); 
				i++;
			}	
			for(j=0;j<num;j++){
				str2[k++]= ' ';
			}	
		}
		else{
			str2[k++] = str1[i++];
		}	

	}
	str2[k] ='\0';
}
//--------------------------------------------------
int main(){
	char str1[N]="Isto#4é#5uma#6pequena#1frase.";
	char str2[N];	
	descompacta(str1, str2);

	printf("Descompacta: %s\n", str2);
 
}
//--------------------------------------------------

