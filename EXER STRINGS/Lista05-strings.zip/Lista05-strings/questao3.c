#include <stdio.h>
#include <string.h>
#include <stdio_ext.h>

//---------------------------------------------------
#define N 100

//---------------------------------------------------
void decodifica(char str1[N], char str2[N]){

	int i;
	int j, k;
	int t = strlen(str1); 

	j = 0;
    k = t - 1;	
	for(i=0; str1[i]!='\0'; ){
		str2[j++] = str1[i++];
		if (str1[i]!='\0'){
			str2[k--] = str1[i++];
		}
	}
	str2[t] ='\0';
}
//--------------------------------------------------
int main(){
	char str1[N] = "ParvoagJr ammea coa";
	char str2[N];	
	decodifica(str1, str2);

	printf("Decodificada: %s\n", str2);
 
}
//--------------------------------------------------

